# 正文—证据映射

所有项目证据路径以下根目录为准：`/root/autodl-tmp/TBSI_gai/TBSI`。此文件供核对，不放入论文正文。

| 正文位置 | 事实/结果 | 直接证据 |
|---|---|---|
| 标题、摘要、引言、方法 | 实际对象为搜索条件化来源 Value 增益，不是 DCVR-v2 | `output/experiments/EG_C_EARLY_LR_DROP_U936_FULL15_FULL244_S42_20261101/C/source_at_launch/lib/models/layers/early_gate_search_context.py`；同快照 `tbsi_layer.py` 与 `vit_tbsi_care.py` |
| 方法：early evidence | RGB/TIR 峰值与模板一致性，3→32→2 原门控 | `lib/models/layers/early_conditioned_msha_gate.py`；历史运行直接报告 `output/experiments/EG_C_EARLY_LR_DROP_U936_FULL15_FULL244_S42_20261101/analysis/m1_comparison_20261101/REPORT.md` |
| 方法：初始化 | 新增检索末层在外层初始化后重新置零；关闭残差与保存加载一致 | 运行快照 `vit_tbsi_care.py` 的 reset 调用；`.../C/train/real_input_contract.json` |
| 主表与完整候选表 | seed42 核心组；B0/M1 与新候选非严格配对 | 用户提供表；`experiments/实验资产数据库.md` 和 `experiment_asset_registry.csv` 对应 ID；M1 比较报告 |
| 训练设置与 LR 对照 | u936 vs u4680 衰减，u7020 终点 | `.../launch.json`、`.../pairing.json`、`.../C/train/checkpoint_u7020.json`；`experiments/early_gate_closed_loop_20261026/c_early_lr_drop_u936_20261101/run_c_early_lr_drop_u936_20261101.py` |
| 调度比较表 | 五指标差值、序列区间、胜平负与 FPS | `output/experiments/EG_C_EARLY_LR_DROP_U936_FULL15_FULL244_S42_20261101/analysis/REPORT.md`、`summary.json` |
| P/S/C 短预算 | 936 updates / screen96；C-P 与 C-S 区间跨零 | `output/experiments/EG_EARLY_GATE_SEARCH_CONTEXT_936_RETRY1_S42_20261031/analysis/REPORT.md`；quick 权重后来清理，保留报告支持历史读数，非新增复测 |
| 短训/full 差异 | 同 cohort 的短预算收益未保持；full P 参照产物不完整 | `experiments/early_gate_search_context_20261031/sequence_analysis_20261101/REPORT.md`；不继承其中旧的后续执行建议 |
| layer-aligned | 新增检索条件改成当前层输入后五指标均下降 | `output/experiments/EG_C_LAYER_ALIGNED_CONTEXT_U936_FULL15_FULL244_S42_20261101/analysis/report.md` |
| 历史 M1 比较与尾部 | full244 +0.6228 pp、142/0/102、237/Q154 敏感性、属性与低IoU帧 | `output/experiments/EG_C_EARLY_LR_DROP_U936_FULL15_FULL244_S42_20261101/analysis/m1_comparison_20261101/{REPORT.md,summary.json,per_sequence_244.csv,frame_behavior_237.csv}` |
| 最终固定 crop 诊断 | 8 状态、u7020、native vs g=1、平均差 −0.000014/绝对差0.000112 | `experiments/early_gate_closed_loop_20261026/c_final_gate_utility_20261102/REPORT.md`；`output/experiments/EG_C_FINAL_GATE_FIXED_CROP_UTILITY_RETRY4_20261102/completed.json` |
| 短训/未完成附表 | C936、T936、T full15 仅62/244 | 用户指定核心组范围与资产登记；没有将新运行状态追加为该组多seed结果 |
| 指标定义 | 等序列汇总；PR20像素/NPR0.2；overlap 严格大于阈值 | `lib/test/analysis/extract_results.py`；`lib/test/analysis/plot_results.py`；当前候选 analysis 评测脚本 |

## 关键身份与 hash（来自现有 manifest；未重新读取大权重计算）

- 公共 SOT 初始化：`pretrained_models/TBSITrack_SOT_Pretrained.pth.tar`
  - SHA256 `1f6ebf5905ed0a404a11beac944ef5d544c9e81605120c2052a2518467d2651b`
- Ours：`EG-C-EARLY-LR-DROP-U936-S42-20261101`
  - 配置：`experiments/tbsi_track/EG_C_EARLY_LR_DROP_U936_SOT_S42_20261101.yaml`
  - 配置 SHA256 `159ff0e31ea1e55dab5b3ac229e7472b050ea98ab257b3da581feb1c77a44f8d`
  - u7020 checkpoint SHA256 `8742d0cd456084e6bd2cb39e8524d1fa5e5b33c9cf7f1eba72ce3bb4cb29148e`
  - 完整初态 hash `90a9c16309f952ccf09f387d014ea2df7068548293c0f39601be41b5bf7cb3d3`
  - u936 模型 state hash `cc5ad9d0eec08aed3e099b26d16dda2ae3f76d7108576e34d7b753088632a598`
  - train manifest SHA256 `5258569430eab4acef1d50656309ee51c634c7a15881a99b40b876d4452a0469`
  - full244 manifest SHA256 `47d7394afd556079fd35077a59d433589a3253fa82654ef289f1ad7666dbddc6`
- 原 C：`EG-SEARCH-CONTEXT-FULL15-C-FULL244-S42-20261031`
  - u7020 checkpoint SHA256 `e7488c72bb669bc9c0239d90772b03176244b59b7f041c09144ef7bb1d991cf2`

运行快照与当前工作区三个主要模型文件有差异；方法以运行快照为主，不将当前 layer-aligned 扩展当作原 C 已执行部分。当前源代码只作接口辅助核对。

## 本次解释修正

- 附件原稿关于“前景 mask + 守恒方向预算 + token 重分配”的公式属于旧提案，与本组结果无对应关系，整体移除。
- 原门控构造函数的末层 zero-init 可能被骨干统一初始化覆盖。运行快照明确恢复的是新增 search-context 分支；正文只陈述有证据支持的“新增残差/off parity”，不据构造函数写整网 g=1。
- 原报告文字写了“五个 native 略优、三个 g=1 略优、一个相等”，合计不一致。正文不抄该计数；仅采用逐项机器结果可支持的8状态均值和合同一致性。
- 调度置信区间固定使用其直接配对 analysis，而 M1 比较使用 m1_comparison analysis。不同重采样实现/种子可造成区间末位差别，不交叉替换。
- M1 的差值采用归档精确值再四舍五入。例如 NPR 精确值为 66.1979574，因此 Ours−M1 为 +0.6368 pp，显示为 +0.64；不能拿显示为66.20的主表数值相减后改为+0.63。

## 直接背景文献

- `10.1109/TIP.2021.3130533`：Crossref DOI BibTeX 与 LasHeR 作者 README 已读取，保存为 `LasHeR_author_README.md`。
- `10.1109/CVPR52729.2023.01310`：Crossref DOI BibTeX 与 TBSI 作者 README 已读取，保存为 `TBSI_author_README.md`；CVF 页面请求失败，不声称已在线阅读全文。
- `10.1109/TPAMI.2024.3475472`：Crossref 题名、作者、出版年份与页码已核对；只作一般背景归属，不据未读全文扩张方法主张。
- 检索日期：北京时间 2026-11-02。DOI 原始元数据见 `reference_metadata.json`。
