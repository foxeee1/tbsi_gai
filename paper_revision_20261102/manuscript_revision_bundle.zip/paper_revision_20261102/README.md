# LaTeX 论文改写稿

主文件：`latex/manuscript_revised.tex`；参考文献：`latex/references.bib`。

本稿沿用中文 IEEEtran 双栏结构，实质性改写了标题、摘要、引言问题设计、方法公式、实验验证及结论。原稿保存在 `original/manuscript_original.tex`，逐行差异见 `manuscript_changes.diff`。

## 本次主要修改

1. **方法与实际结果对应。** 删除旧 DCVR-v2 提案的前景 mask、方向预算守恒、熵/竞争差路由等主方法公式，改为运行时快照可确认的 C：来源模板检索对侧当前搜索内容，与原有 early evidence 共同预测来源 Value 的残差增益。
2. **问题表述收窄。** 不再把系统级 crop 漂移直接归因于模板 MHSA；也不把 Early gate 写成没有搜索条件。研究问题变为“三维搜索摘要之外，显式内容检索是否使 Value 调制更有任务效用”。
3. **主结果角色明确。** 正文以 B0、M1、Ours 呈现系统发展；附录保留全部九行完整预算/full244 核心组，另列短预算和未完成结果。
4. **结构和调度分开。** Ours 明确定义为 C + u936 提前降 LR。C→Ours 为调度对照，不写成新算子消融；保留共同初态、增强输入及 u936 state 一致性证据。
5. **验证写成已完成的工作。** 加入 P/S/C 短预算开发对照、layer-aligned 负结果、逐序列尾部、来源敏感性及最终 checkpoint 的八个固定 crop 干预。没有把待执行实验写成完成。
6. **同步摘要与结论。** 相对 B0 五项均超过 +1.5 pp，相对 M1 AUC/OP75 为 +0.62/+1.91 pp；明确区分这两类差值。

## 特别修正

- 完整九行候选中，历史 P 的 PR 70.58 高于 Ours 的 70.4502。完整表只将 Ours 的 AUC/NPR/OP50/OP75 加粗。
- 当前 C 没有前景输入、预算守恒或 Value 方向修正，不能承接原稿这些创新表述。
- 新增残差初始化与原 Early gate 一致，不笼统声称整个门控初始化必为 g=1。已引用真实输入的 zero-residual/off/save-load 输出一致性记录。
- 历史 M1 来源敏感性和八个 crop 的微小动作效应均保留，但不把小样本诊断外推为模块普遍无效。
- 主文不写本地资产管理规则和准入流程；具体路径及校验值转入 `EVIDENCE_MAP.md`。

## 使用

将 `latex/` 中两个文件放入现有 LaTeX 项目，设置 `manuscript_revised.tex` 为主文件，选择 **XeLaTeX**。建议本地构建顺序：

```bash
cd latex
xelatex -interaction=nonstopmode -halt-on-error manuscript_revised.tex
bibtex manuscript_revised
xelatex -interaction=nonstopmode -halt-on-error manuscript_revised.tex
xelatex -interaction=nonstopmode -halt-on-error manuscript_revised.tex
```

源码保留 SimSun/SimHei 字体支持；缺少这些字体时回退到 TeX Live 的 Fandol 字体。

当前环境没有 XeLaTeX/LaTeX/BibTeX 引擎，因此没有生成 PDF，也未完成渲染版式检查。静态与数值核对结果见 `VALIDATION.md`。作者和单位仍保留原稿占位，需要自行填写。

## 文献边界

原附件未带 `.bib`。本次提供从 Crossref DOI 接口取得的三条直接背景文献；已核对 TBSI 与 LasHeR 作者仓库说明。TPAMI 延伸工作只核对题名/出版元数据，未据它扩张算子新颖性主张。旧稿中未核验的近期文献不再用于当前论证。

这是一份与当前实验相符的实质性修改稿，尚不是完成外部 SOTA 对照、独立确认、完整相关工作检索与版面检查的投稿定稿。本次没有启动训练、推理或研究分析，也没有修改历史资产表及实验文件。
