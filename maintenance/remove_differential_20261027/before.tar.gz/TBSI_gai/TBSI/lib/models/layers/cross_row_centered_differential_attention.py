"""Cross-modal differential relations with per-receiver row-mass centering."""
import torch
import torch.nn as nn


class CrossRowCenteredDifferentialAttention(nn.Module):
    """Build a signed cross-source correction whose source-axis sum is zero."""
    def __init__(self, dim, num_heads, rank=16, coefficient_gain=16.0):
        super().__init__()
        if dim % num_heads:
            raise ValueError('dim must be divisible by num_heads')
        self.num_heads = int(num_heads)
        self.rank = int(rank)
        self.scale = self.rank ** -0.5
        self.coefficient_gain = float(coefficient_gain)
        self.query = nn.Linear(dim, self.num_heads * self.rank, bias=False)
        self.key = nn.Linear(dim, self.num_heads * self.rank, bias=False)
        self.coefficient = nn.Parameter(torch.zeros(self.num_heads))

    def forward(self, tokens):
        if tokens.ndim != 3:
            raise ValueError('tokens must have shape [B, L, C]')
        batch, length, dim = tokens.shape
        if length % 2:
            raise ValueError('row-centered cross attention expects two equal token groups')
        half = length // 2
        q = self.query(tokens).view(batch, length, self.num_heads, self.rank).transpose(1, 2)
        k = self.key(tokens).view(batch, length, self.num_heads, self.rank).transpose(1, 2)
        relation = torch.softmax((q @ k.transpose(-2, -1)) * self.scale, dim=-1)
        rgb_to_tir = relation[:, :, :half, half:]
        tir_to_rgb = relation[:, :, half:, :half]
        rgb_to_tir = rgb_to_tir - rgb_to_tir.mean(dim=-1, keepdim=True)
        tir_to_rgb = tir_to_rgb - tir_to_rgb.mean(dim=-1, keepdim=True)
        zeros = relation.new_zeros(batch, self.num_heads, half, half)
        correction = torch.cat((torch.cat((zeros, rgb_to_tir), dim=-1),
                                torch.cat((tir_to_rgb, zeros), dim=-1)), dim=-2)
        scale = self.coefficient.to(correction.dtype) * self.coefficient_gain
        return correction * scale[None, :, None, None]
