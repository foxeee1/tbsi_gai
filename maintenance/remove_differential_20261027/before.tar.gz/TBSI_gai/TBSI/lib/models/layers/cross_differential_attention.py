"""Low-rank differential relation correction for cross-modal template messages."""
import torch
import torch.nn as nn


class CrossDifferentialAttention(nn.Module):
    def __init__(self, dim, num_heads, rank=16):
        super().__init__()
        if dim % num_heads:
            raise ValueError('dim must be divisible by num_heads')
        self.num_heads = int(num_heads)
        self.rank = int(rank)
        self.query = nn.Linear(dim, self.num_heads * self.rank, bias=False)
        self.key = nn.Linear(dim, self.num_heads * self.rank, bias=False)
        self.scale = self.rank ** -0.5
        # Keep the identity start while making the relation projections receive
        # usable gradients after the zero-initialized per-head coefficient moves.
        self.coefficient_gain = 16.0
        self.coefficient = nn.Parameter(torch.zeros(self.num_heads))

    def forward(self, tokens):
        if tokens.ndim != 3:
            raise ValueError('tokens must have shape [B, L, C]')
        batch, length, _ = tokens.shape
        query = self.query(tokens).view(batch, length, self.num_heads, self.rank)
        key = self.key(tokens).view(batch, length, self.num_heads, self.rank)
        query = query.permute(0, 2, 1, 3)
        key = key.permute(0, 2, 1, 3)
        relation = torch.matmul(query, key.transpose(-2, -1)) * self.scale
        relation = relation.softmax(dim=-1)
        effective_coefficient = self.coefficient.to(relation.dtype) * self.coefficient_gain
        return relation * effective_coefficient[None, :, None, None]
