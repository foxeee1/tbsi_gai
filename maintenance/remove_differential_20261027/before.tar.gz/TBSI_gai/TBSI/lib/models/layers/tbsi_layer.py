"""
TBSILayer: Core cross-attention between RGB and TIR modalities.
Supports degradation-aware modulation at the per-layer level.
"""
import os
import torch
import torch.nn as nn
from lib.models.layers.attn_blocks import CASTBlock
from lib.models.layers.early_conditioned_msha_gate import (
    EarlyConditionedMSHAGate, early_msha_gate_evidence,
)
from lib.models.layers.early_source_evidence import EarlySourceEvidence
from lib.models.layers.structured_spatial_evidence import StructuredSpatialEvidence
from lib.models.layers.dual_message_modulator import DualMessageModulator
from lib.models.layers.cross_differential_attention import CrossDifferentialAttention
from lib.models.layers.cross_row_centered_differential_attention import CrossRowCenteredDifferentialAttention


class V2TemplateFusion(nn.Module):
    """V2-style joint template MHSA, kept behind an explicit feature gate."""

    def __init__(self, dim, num_heads, qkv_bias=False, drop=0., attn_drop=0.,
                 norm_layer=nn.LayerNorm, early_conditioned_cross_gate=False,
                 early_gate_hidden=32, early_source_evidence=False,
                 early_source_evidence_hidden=24, early_source_evidence_delta=0.25,
                 early_source_evidence_topk=4, structured_spatial_evidence=False,
                 structured_evidence_hidden=8, dual_message_mode='off',
                 dual_message_max_delta=0.1,
                 cross_differential_attention=False, cross_differential_rank=16,
                 cross_differential_row_centered=False):
        super().__init__()
        self.norm = norm_layer(dim)
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(drop)
        self.early_conditioned_cross_gate = bool(early_conditioned_cross_gate)
        self.structured_spatial_evidence_enabled = bool(structured_spatial_evidence)
        self.dual_message_mode = str(dual_message_mode).lower()
        self.cross_differential_attention_enabled = bool(cross_differential_attention)
        self.cross_differential_row_centered = bool(cross_differential_row_centered)
        if self.dual_message_mode in ('false', 'none'):
            self.dual_message_mode = 'off'
        if self.dual_message_mode != 'off' and not self.structured_spatial_evidence_enabled:
            raise ValueError('active D mode requires the structured E encoder')
        self.structured_support_logits = None
        if self.structured_spatial_evidence_enabled:
            self.structured_evidence = StructuredSpatialEvidence(structured_evidence_hidden)
        if self.dual_message_mode != 'off':
            if self.dual_message_mode not in ('cross_summary', 'cross_structured', 'dual_structured'):
                raise ValueError('unknown dual message mode: ' + self.dual_message_mode)
            self.dual_message = DualMessageModulator(
                dim=dim, evidence_dim=32, max_delta=dual_message_max_delta)
        if self.early_conditioned_cross_gate:
            self.early_gate = EarlyConditionedMSHAGate(early_gate_hidden)
            self.early_gate_scale = nn.Parameter(torch.tensor(0.1))
            self.early_source_evidence_enabled = bool(early_source_evidence)
            if self.early_source_evidence_enabled:
                self.early_source_evidence = EarlySourceEvidence(
                    hidden_dim=early_source_evidence_hidden,
                    max_delta=early_source_evidence_delta,
                    topk=early_source_evidence_topk)
        else:
            self.early_source_evidence_enabled = False
        if self.cross_differential_attention_enabled:
            if not self.early_conditioned_cross_gate:
                raise ValueError('cross differential attention requires the Early gate parent path')
            operator = (CrossRowCenteredDifferentialAttention if self.cross_differential_row_centered
                        else CrossDifferentialAttention)
            self.cross_differential_attention = operator(dim=dim, num_heads=num_heads, rank=cross_differential_rank)

    def forward(self, x_rgb_template, x_tir_template, early_context=None,
                template_boxes=None):
        # The two modality template streams interact jointly, then are split
        # back so the surrounding ViT and search path remain unchanged.
        x = torch.cat([x_rgb_template, x_tir_template], dim=1)
        residual = x
        x = self.norm(x)
        bsz, length, dim = x.shape
        qkv = self.qkv(x).reshape(bsz, length, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        logits = (q @ k.transpose(-2, -1)) * self.scale
        attention = logits.softmax(dim=-1)
        attn = self.attn_drop(attention)
        if self.early_conditioned_cross_gate:
            evidence, rgb_similarity, tir_similarity = early_msha_gate_evidence(
                early_context, x_rgb_template, x_tir_template)
            if self.early_source_evidence_enabled:
                evidence = self.early_source_evidence(
                    evidence, rgb_similarity, tir_similarity)
            gate = torch.exp(torch.tanh(self.early_gate_scale) *
                             torch.tanh(self.early_gate(evidence.to(x.dtype)))).clamp(0.25, 4.0)
            n_rgb = x_rgb_template.shape[1]
            if self.structured_spatial_evidence_enabled:
                if template_boxes is None:
                    raise ValueError('E/D requires transformed first-frame template boxes')
                state_rgb, state_tir, support_logits, coverage, _ = self.structured_evidence(
                    rgb_similarity, tir_similarity, template_boxes, evidence,
                    action_mode=('summary' if self.dual_message_mode == 'cross_summary'
                                 else 'structured'))
                self.structured_support_logits = support_logits
            else:
                state_rgb = state_tir = None
                self.structured_support_logits = None
            v_rgb, v_tir = v[:, :, :n_rgb], v[:, :, n_rgb:]
            cross_rgb, cross_tir = v_rgb, v_tir
            if hasattr(self, 'value_direction') and self.value_direction_enabled:
                mode = self.value_direction_mode
                rgb_kwargs, tir_kwargs = {}, {}
                if getattr(self, 'value_direction_aligned_enabled', False):
                    rgb_kwargs['receiver_attention'] = attn[:, :, n_rgb:, :n_rgb]
                    tir_kwargs['receiver_attention'] = attn[:, :, :n_rgb, n_rgb:]
                cross_rgb = self.value_direction(
                    cross_rgb, x_rgb_template, x_tir_template, evidence, mode=mode, **rgb_kwargs)
                # Canonical evidence is relative to the source role.
                cross_tir = self.value_direction(
                    cross_tir, x_tir_template, x_rgb_template,
                    evidence[..., [1, 0, 2]], mode=mode, **tir_kwargs)
            msg_rr = attn[:, :, :n_rgb, :n_rgb] @ v_rgb
            msg_tt = attn[:, :, n_rgb:, n_rgb:] @ v_tir
            # Preserve the parent's attention-dropout path exactly. The second
            # relation is a deterministic correction and adds no RNG draws.
            attn_rt = attn[:, :, :n_rgb, n_rgb:]
            attn_tr = attn[:, :, n_rgb:, :n_rgb]
            if self.cross_differential_attention_enabled:
                correction = self.cross_differential_attention(x)
                attn_rt = attn_rt - correction[:, :, :n_rgb, n_rgb:]
                attn_tr = attn_tr - correction[:, :, n_rgb:, :n_rgb]
            msg_rt = attn_rt @ (cross_tir * gate[:, None, :, 1:2])
            msg_tr = attn_tr @ (cross_rgb * gate[:, None, :, 0:1])
            if self.dual_message_mode != 'off':
                scale_rr, scale_rt, _message_diag_rgb = self.dual_message(
                    state_rgb, state_tir, coverage[:, 0], coverage[:, 1],
                    msg_rr, msg_rt, attention[:, :, :n_rgb, :n_rgb],
                    attention[:, :, :n_rgb, n_rgb:],
                    enable_self=self.dual_message_mode == 'dual_structured')
                scale_tt, scale_tr, _message_diag_tir = self.dual_message(
                    state_tir, state_rgb, coverage[:, 1], coverage[:, 0],
                    msg_tt, msg_tr, attention[:, :, n_rgb:, n_rgb:],
                    attention[:, :, n_rgb:, :n_rgb],
                    enable_self=self.dual_message_mode == 'dual_structured')
                msg_rr = msg_rr * scale_rr[:, None, :, :]
                msg_rt = msg_rt * scale_rt[:, None, :, :]
                msg_tt = msg_tt * scale_tt[:, None, :, :]
                msg_tr = msg_tr * scale_tr[:, None, :, :]
            rgb = msg_rr + msg_rt
            tir = msg_tt + msg_tr
            x = torch.cat((rgb, tir), dim=2).transpose(1, 2).reshape(bsz, length, dim)
        else:
            x = (attn @ v).transpose(1, 2).reshape(bsz, length, dim)
        x = residual + self.proj_drop(self.proj(x))
        return x[:, :x_rgb_template.shape[1]], x[:, x_rgb_template.shape[1]:]


class DegradationModulator(nn.Module):
    """
    [Phase 1 Fix] Joint modality confidence estimator for TBSILayer.

    First-principles fix:
      - BEFORE: independent MLPs for RGB and TIR — violates "reliability is a
        relationship property" (a token is reliable RELATIVE to the other modality)
      - AFTER: single joint MLP on cat(rgb, tir) → [conf_v, conf_i]
        The joint representation captures cross-modal contrast, so a token with
        poor RGB but good TIR correctly gets low conf_v and high conf_i.

    Architecture:
      - Input: cat(x_v_search, x_i_search)  →  (B, N_s, 2*C)
      - Joint MLP: Linear(2C → rdim) → ReLU → Linear(rdim → 2)
      - Output split: [conf_v, conf_i], each (B, N_s, 1) in [0,1]
    """
    def __init__(self, dim, reduction=4, temporal_dim=None):
        super().__init__()
        rdim = max(dim // reduction, 16)
        input_dim = dim * 2  # always joint: cat(rgb, tir)
        self.use_temporal = temporal_dim is not None
        if self.use_temporal:
            input_dim = dim * 2 + temporal_dim  # cat(rgb, tir, temporal)

        self.conf_joint = nn.Sequential(
            nn.Linear(input_dim, rdim),
            nn.ReLU(inplace=True),
            nn.Linear(rdim, 2),  # 2 outputs: [conf_v, conf_i]
            nn.Sigmoid(),
        )
        # Zero-init last layer: initial sigmoid(0) ≈ 0.5 → uniform confidence
        nn.init.zeros_(self.conf_joint[-2].weight)
        nn.init.zeros_(self.conf_joint[-2].bias)

    def forward(self, x_v_search, x_i_search, temporal_tokens=None):
        """
        Args:
            x_v_search: (B, N_s, C) visible search tokens
            x_i_search: (B, N_s, C) infrared search tokens
        Returns:
            conf_v, conf_i: each (B, N_s, 1) confidence in [0,1]
        """
        if self.use_temporal and temporal_tokens is not None:
            t = temporal_tokens.mean(dim=1, keepdim=True).expand(-1, x_v_search.shape[1], -1)
            joint_inp = torch.cat([x_v_search, x_i_search, t], dim=-1)
        else:
            joint_inp = torch.cat([x_v_search, x_i_search], dim=-1)

        conf_joint = self.conf_joint(joint_inp)  # (B, N_s, 2)
        conf_v = conf_joint[:, :, 0:1]           # (B, N_s, 1)
        conf_i = conf_joint[:, :, 1:2]           # (B, N_s, 1)
        return conf_v, conf_i


class TBSILayer(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, use_degradation=False,
                 use_attn_gate=False, use_temporal_tokens=False,
                 use_smsa=False, use_smsa_rgb=None, use_smsa_tir=None,
                 smsa_alpha=1.3, smsa_fp32=True, fusion_mode='legacy',
                 early_conditioned_cross_gate=False, early_gate_hidden=32,
                 early_source_evidence=False, early_source_evidence_hidden=24,
                 early_source_evidence_delta=0.25, early_source_evidence_topk=4,
                 structured_spatial_evidence=False, structured_evidence_hidden=8,
                 dual_message_mode='off', dual_message_max_delta=0.1,
                 cross_differential_attention=False, cross_differential_rank=16,
                 cross_differential_row_centered=False):
        super().__init__()
        self.fusion_mode = fusion_mode
        if fusion_mode == 'tbsi_e':
            # Match the archived parent state: no dead legacy bridge weights.
            self.v2_template_fusion = V2TemplateFusion(
                dim=dim, num_heads=num_heads, qkv_bias=qkv_bias,
                drop=drop, attn_drop=attn_drop, norm_layer=norm_layer,
                early_conditioned_cross_gate=early_conditioned_cross_gate,
                early_gate_hidden=early_gate_hidden,
                early_source_evidence=early_source_evidence,
                early_source_evidence_hidden=early_source_evidence_hidden,
                early_source_evidence_delta=early_source_evidence_delta,
                early_source_evidence_topk=early_source_evidence_topk,
                structured_spatial_evidence=structured_spatial_evidence,
                structured_evidence_hidden=structured_evidence_hidden,
                dual_message_mode=dual_message_mode,
                dual_message_max_delta=dual_message_max_delta,
                cross_differential_attention=cross_differential_attention,
                cross_differential_rank=cross_differential_rank,
                cross_differential_row_centered=cross_differential_row_centered)
            return

        self.t_fusion = nn.Sequential(
            nn.Linear(dim * 2, dim),
            nn.LayerNorm(dim),
            nn.GELU()
        )
        self.fusion_mode = fusion_mode
        if fusion_mode in ('v2', 'tbsi_e'):
            self.v2_template_fusion = V2TemplateFusion(
                dim=dim, num_heads=num_heads, qkv_bias=qkv_bias,
                drop=drop, attn_drop=attn_drop, norm_layer=norm_layer,
                early_conditioned_cross_gate=early_conditioned_cross_gate,
                early_gate_hidden=early_gate_hidden,
                early_source_evidence=early_source_evidence,
                early_source_evidence_hidden=early_source_evidence_hidden,
                early_source_evidence_delta=early_source_evidence_delta,
                early_source_evidence_topk=early_source_evidence_topk,
                structured_spatial_evidence=structured_spatial_evidence,
                structured_evidence_hidden=structured_evidence_hidden,
                dual_message_mode=dual_message_mode,
                dual_message_max_delta=dual_message_max_delta,
                cross_differential_attention=cross_differential_attention,
                cross_differential_rank=cross_differential_rank,
                cross_differential_row_centered=cross_differential_row_centered)

        self.ca_s2t_v2f = CASTBlock(
            dim=dim, num_heads=num_heads, mode='s2t', mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop,
            attn_drop=attn_drop, drop_path=drop_path, norm_layer=norm_layer, act_layer=act_layer,
            use_attn_gate=use_attn_gate,
            use_smsa=use_smsa if use_smsa_tir is None else use_smsa_tir,
            smsa_alpha=smsa_alpha,
            smsa_fp32=smsa_fp32
        )
        self.ca_t2s_f2i = CASTBlock(
            dim=dim, num_heads=num_heads, mode='t2s', mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop,
            attn_drop=attn_drop, drop_path=drop_path, norm_layer=norm_layer, act_layer=act_layer,
            use_attn_gate=use_attn_gate
        )
        self.ca_s2t_i2f = CASTBlock(
            dim=dim, num_heads=num_heads, mode='s2t', mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop,
            attn_drop=attn_drop, drop_path=drop_path, norm_layer=norm_layer, act_layer=act_layer,
            use_attn_gate=use_attn_gate,
            use_smsa=use_smsa if use_smsa_rgb is None else use_smsa_rgb,
            smsa_alpha=smsa_alpha,
            smsa_fp32=smsa_fp32
        )
        self.ca_t2s_f2v = CASTBlock(
            dim=dim, num_heads=num_heads, mode='t2s', mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop,
            attn_drop=attn_drop, drop_path=drop_path, norm_layer=norm_layer, act_layer=act_layer,
            use_attn_gate=use_attn_gate
        )
        self.ca_t2t_f2v = CASTBlock(
            dim=dim, num_heads=num_heads, mode='t2t', mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop,
            attn_drop=attn_drop, drop_path=drop_path, norm_layer=norm_layer, act_layer=act_layer,
            use_attn_gate=use_attn_gate
        )
        self.ca_t2t_f2i = CASTBlock(
            dim=dim, num_heads=num_heads, mode='t2t', mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, drop=drop,
            attn_drop=attn_drop, drop_path=drop_path, norm_layer=norm_layer, act_layer=act_layer,
            use_attn_gate=use_attn_gate
        )

        self.use_degradation = use_degradation
        if use_degradation:
            # Only enable temporal context in DM when temporal tokens are actually running
            temporal_dim = dim if use_temporal_tokens else None
            self.degradation_mod = DegradationModulator(dim, temporal_dim=temporal_dim)

    def forward(self, x_v, x_i, lens_z, temporal_tokens=None, early_context=None,
                template_boxes=None):
        # x_v: [B, N, C], N = 320 (64 template + 256 search)
        # x_i: [B, N, C]
        if self.fusion_mode == 'tbsi_e':
            fused_v, fused_i = self.v2_template_fusion(
                x_v[:, :lens_z, :], x_i[:, :lens_z, :], early_context=early_context,
                template_boxes=template_boxes)
            # Retained TBSI-E updates templates only. Subsequent ViT blocks
            # propagate these changes to search tokens; legacy bridges do not run.
            return (torch.cat([fused_v, x_v[:, lens_z:, :]], dim=1),
                    torch.cat([fused_i, x_i[:, lens_z:, :]], dim=1))
        if self.fusion_mode == 'v2':
            fused_v, fused_i = self.v2_template_fusion(
                x_v[:, :lens_z, :], x_i[:, :lens_z, :], early_context=early_context,
                template_boxes=template_boxes)
            x_v = torch.cat([fused_v, x_v[:, lens_z:, :]], dim=1)
            x_i = torch.cat([fused_i, x_i[:, lens_z:, :]], dim=1)
            # Continue through the standard TBSI interaction path. V2 changes
            # only the template initialization; search/template interaction
            # and its optional SMSA remain active and attributable.

        fused_t = torch.cat([x_v[:, :lens_z, :], x_i[:, :lens_z, :]], dim=2)
        fused_t = self.t_fusion(fused_t)  # [B, 64, C]

        if self.use_degradation:
            # Per-patch confidence for search regions (with optional temporal context)
            conf_v, conf_i = self.degradation_mod(x_v[:, lens_z:, :], x_i[:, lens_z:, :],
                                                  temporal_tokens=temporal_tokens)
            # conf_v: (B, N_s, 1) high where RGB reliable
            # conf_i: (B, N_s, 1) high where TIR reliable
            # qm_v/qm_i: quality masks for cross-attention modulation
            qm_v = conf_v  # visible quality → modulate visible-related CA
            qm_i = conf_i  # infrared quality → modulate infrared-related CA

        # Search-to-Template: infrared search → fused template (use ir quality mask)
        fused_t = self.ca_s2t_i2f(torch.cat([fused_t, x_i[:, lens_z:, :]], dim=1),
                                  quality_mask=qm_i if self.use_degradation else None)[:, :lens_z, :]

        # Template-to-Search: fused template → visible search (use vis quality mask)
        temp_x_v = self.ca_t2s_f2v(torch.cat([fused_t, x_v[:, lens_z:, :]], dim=1),
                                   quality_mask=qm_v if self.use_degradation else None)[:, lens_z:, :]

        # Search-to-Template: visible search → fused template (use vis quality mask)
        fused_t = self.ca_s2t_v2f(torch.cat([fused_t, x_v[:, lens_z:, :]], dim=1),
                                  quality_mask=qm_v if self.use_degradation else None)[:, :lens_z, :]

        # Template-to-Search: fused template → infrared search (use ir quality mask)
        temp_x_i = self.ca_t2s_f2i(torch.cat([fused_t, x_i[:, lens_z:, :]], dim=1),
                                   quality_mask=qm_i if self.use_degradation else None)[:, lens_z:, :]

        # Apply degradation-aware gating if enabled (实验1)
        if self.use_degradation:
            x_v = torch.cat([x_v[:, :lens_z, :], temp_x_v * (1 - conf_v) + x_v[:, lens_z:, :] * conf_v], dim=1)
            x_i = torch.cat([x_i[:, :lens_z, :], temp_x_i * (1 - conf_i) + x_i[:, lens_z:, :] * conf_i], dim=1)
        else:
            x_v = torch.cat([x_v[:, :lens_z, :], temp_x_v], dim=1)
            x_i = torch.cat([x_i[:, :lens_z, :], temp_x_i], dim=1)

        # Template self-attention (no quality_mask — operates on template tokens)
        x_v[:, :lens_z, :] = self.ca_t2t_f2v(torch.cat([x_v[:, :lens_z, :], fused_t], dim=1))[:, :lens_z, :]
        x_i[:, :lens_z, :] = self.ca_t2t_f2i(torch.cat([x_i[:, :lens_z, :], fused_t], dim=1))[:, :lens_z, :]

        return x_v, x_i

    def get_smsa_stats(self):
        if self.fusion_mode == 'tbsi_e':
            return None
        stats = []
        for block in (self.ca_s2t_i2f, self.ca_s2t_v2f):
            value = getattr(block.attn_reshape, 'smsa_stats', None)
            if value is not None:
                stats.append(value)
        if not stats:
            return None
        return {key: sum(item[key] for item in stats) / len(stats) for key in stats[0]}
