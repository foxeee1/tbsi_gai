#!/usr/bin/env python3
"""Paired, per-sequence comparison for Early gate differential attention P1."""
import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from lib.test.analysis.extract_results import calc_seq_err_robust

METRICS = ('AUC', 'PR', 'NPR', 'OP50', 'OP75')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def measure(pred_path, gt_path):
    pred = np.loadtxt(str(pred_path), ndmin=2)
    gt = np.loadtxt(str(gt_path), delimiter=',', ndmin=2)
    if pred.shape != gt.shape or not np.isfinite(pred).all():
        raise ValueError('Prediction shape/finite check failed: ' + str(pred_path))
    overlap, center, norm, valid = calc_seq_err_robust(
        torch.tensor(pred, dtype=torch.float64), torch.tensor(gt, dtype=torch.float64), 'lasher')
    overlap, center, norm, valid = overlap.numpy(), center.numpy(), norm.numpy(), valid.numpy()
    thresholds = np.arange(0., 1.00001, .05)
    return {'AUC': float(100 * np.mean([(overlap > t).mean() for t in thresholds])),
            'PR': float(100 * (center <= 20).mean()),
            'NPR': float(100 * (norm <= .2).mean()),
            'OP50': float(100 * (overlap > .5).mean()),
            'OP75': float(100 * (overlap > .75).mean()),
            'failure_fraction': float((overlap < .1).mean()),
            'iou': overlap}


def summary(rows, seed=20261027):
    out = {'n': len(rows)}
    for metric in METRICS:
        delta = np.asarray([r['delta_' + metric] for r in rows])
        rng = np.random.RandomState(seed)
        boots = rng.choice(delta, (10000, len(delta)), replace=True).mean(1)
        out[metric] = {'parent': float(np.mean([r['parent_' + metric] for r in rows])),
                       'candidate': float(np.mean([r['candidate_' + metric] for r in rows])),
                       'delta': float(delta.mean()), 'median_delta': float(np.median(delta)),
                       'wins': int((delta > 1.e-6).sum()), 'ties': int((np.abs(delta) <= 1.e-6).sum()),
                       'losses': int((delta < -1.e-6).sum()),
                       'losses_below_minus_5pp': int((delta < -5).sum()),
                       'bootstrap_90pct': np.quantile(boots, [.05, .95]).tolist(),
                       'bootstrap_95pct': np.quantile(boots, [.025, .975]).tolist(),
                       'worst_decile_mean': float(np.sort(delta)[:max(1, int(np.ceil(.1*len(delta))))].mean()),
                       'mean_without_top3_gains': float(np.sort(delta)[:-3].mean()) if len(delta) > 3 else None}
    return out


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--parent-results', required=True)
    parser.add_argument('--candidate-results', required=True)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--sequence-list', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    parent_dir, candidate_dir = Path(args.parent_results), Path(args.candidate_results)
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads(Path(args.manifest).read_text())
    wanted = Path(args.sequence_list).read_text().splitlines()
    records = {row['sequence']: row for row in manifest['test_sequences']}
    if len(wanted) != 96 or len(set(wanted)) != 96 or not set(wanted) <= set(records):
        raise ValueError('Frozen 96-sequence membership mismatch')
    measured = []
    for name in wanted:
        info = records[name]
        gt_path = ROOT / 'data/lasher/testingset' / name / 'init.txt'
        p, c = measure(parent_dir / (name + '.txt'), gt_path), measure(candidate_dir / (name + '.txt'), gt_path)
        if len(p['iou']) != info['frames'] or len(c['iou']) != info['frames']:
            raise ValueError('Prediction frame count mismatch: ' + name)
        measured.append({'sequence': name, 'frames': info['frames'],
                         'parent_result_sha256': digest(parent_dir / (name + '.txt')),
                         'candidate_result_sha256': digest(candidate_dir / (name + '.txt')),
                         'parent_iou': p.pop('iou'), 'candidate_iou': c.pop('iou'),
                         **{'parent_' + k: v for k, v in p.items()},
                         **{'candidate_' + k: v for k, v in c.items()}})
    ranked = sorted(measured, key=lambda row: (row['parent_AUC'], row['sequence']))
    groups = {'low_auc': [r['sequence'] for r in ranked[:32]],
              'middle_auc': [r['sequence'] for r in ranked[32:64]],
              'normal_auc': [r['sequence'] for r in ranked[64:]]}
    membership = {name: label for label, names in groups.items() for name in names}
    rows = []
    for row in measured:
        ip, ic = np.asarray(row['parent_iou']), np.asarray(row['candidate_iou'])
        flat = {k: v for k, v in row.items() if k not in ('parent_iou', 'candidate_iou')}
        flat['group'] = membership[row['sequence']]
        for metric in METRICS:
            flat['delta_' + metric] = row['candidate_' + metric] - row['parent_' + metric]
        flat['recovered_frames_parent_iou_lt_0.1_to_candidate_ge_0.5'] = int(((ip < .1) & (ic >= .5)).sum())
        flat['new_failure_frames_parent_iou_ge_0.5_to_candidate_lt_0.1'] = int(((ip >= .5) & (ic < .1)).sum())
        rows.append(flat)
    with (output / 'per_sequence.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    summary_data = {'scope': {'sequences': 96, 'frames': sum(r['frames'] for r in rows),
                    'dataset': 'LasHeR testingset', 'precision': 'FP32', 'threads': 0,
                    'template_update': False, 'thresholds': 'IoU > 0.00..1.00 step 0.05; PR center error <=20 px; NPR normalized center error <=0.20'},
                    'group_definition': 'AUC tertiles sorted from the paired Early gate P control results on the frozen 96 list; candidate metrics do not affect group membership',
                    'all': summary(rows),
                    **{label: summary([r for r in rows if r['group'] == label]) for label in groups},
                    'sequence_groups': groups}
    (output / 'summary.json').write_text(json.dumps(summary_data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    lines = ['# Early gate + 差分注意力：快速配对结果', '',
             '| 分组 | n | ΔAUC (pp) | 90%序列区间 | 胜/平/负 | >5pp损失 | ΔPR | ΔNPR |',
             '|---|---:|---:|---|---:|---:|---:|---:|']
    for label in ('all', 'low_auc', 'middle_auc', 'normal_auc'):
        s = summary_data[label]
        lines.append('| %s | %d | %+.4f | [%+.4f, %+.4f] | %d/%d/%d | %d | %+.4f | %+.4f |' %
                     (label, s['n'], s['AUC']['delta'], *s['AUC']['bootstrap_90pct'],
                      s['AUC']['wins'], s['AUC']['ties'], s['AUC']['losses'],
                      s['AUC']['losses_below_minus_5pp'], s['PR']['delta'], s['NPR']['delta']))
    low = sorted([r for r in rows if r['group'] == 'low_auc'], key=lambda r: r['delta_AUC'])
    high = sorted(rows, key=lambda r: r['delta_AUC'])
    lines += ['', '候选逐序列表：`per_sequence.csv`；组员冻结表：`summary.json`。',
              '最差10序列：' + ', '.join('%s(%+.2f)' % (r['sequence'], r['delta_AUC']) for r in high[:10]),
              '低AUC组最差5条：' + ', '.join('%s(%+.2f)' % (r['sequence'], r['delta_AUC']) for r in low[:5]),
              '', '解释边界：单 seed、468 成功更新、固定96序列开发 cohort。序列bootstrap只量化当前checkpoint跨序列不确定性，不代表训练seed方差；本结果不能保证后续全量同方向。']
    (output / 'report.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: summary_data[k] for k in ('all', 'low_auc', 'middle_auc', 'normal_auc')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
