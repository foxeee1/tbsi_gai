#!/usr/bin/env python3
"""Aggregate learned-path attribution without treating diagnostics as validation."""
import csv
import json
import math
import sys
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.attribute_differential_attention_p1 import OUT,PRUN,DRUN,measure,table,write,digest


def main():
    probes=json.loads((OUT/'fixed_crop_probes.json').read_text())
    replay=json.loads((OUT/'closed_loop_results.json').read_text())
    bn=json.loads((OUT/'bn_followup_results.json').read_text())
    messages=list(csv.DictReader((OUT/'message_by_head.csv').open()))
    parity=list(csv.DictReader((OUT/'parity.csv').open()))
    stats={}
    for var in ('off','half','uniform'):
        rows=[r for r in probes if r['variant']==var and r['D_iou'] is not None]
        delta=np.asarray([r['intervention_iou']-r['D_iou'] for r in rows])
        seqs=sorted({r['sequence'] for r in rows})
        stats[var]={'n':len(rows),'frame_weighted_mean_iou_delta_pp':float(100*delta.mean()),
                    'equal_sequence_mean_iou_delta_pp':float(np.mean([100*np.mean([r['intervention_iou']-r['D_iou'] for r in rows if r['sequence']==name]) for name in seqs])),
                    'median_abs_box_coordinate_change_px':float(np.median([r['box_max_abs_change'] for r in rows])),
                    'max_abs_box_coordinate_change_px':max(r['box_max_abs_change'] for r in rows),
                    'CENTER_peak_flips':sum(r['D_CENTER_peak']!=r['intervention_CENTER_peak'] for r in rows),
                    'iou_improvement_gt_0_01':int((delta>.01).sum()),'iou_harm_lt_minus_0_01':int((delta<-.01).sum())}
    message_stats={}
    for key in ('correction_to_base_message_l2','negative_effective_weight_fraction',
                'B_conditional_entropy_over_log64','B_to_uniform_total_variation',
                'A_fg_spatial_mass','B_fg_spatial_mass','uniform_fg_spatial_mass'):
        v=np.array([float(r[key]) for r in messages])
        message_stats[key]={'mean':float(v.mean()),'p10':float(np.quantile(v,.1)),
                            'median':float(np.median(v)),'p90':float(np.quantile(v,.9)),'max':float(v.max())}
    for r in replay:
        r['off_minus_D_AUC']=r['off_AUC']-r['D_AUC'];r['off_minus_P_AUC']=r['off_AUC']-r['P_AUC']
    table(OUT/'closed_loop_comparison.csv',[{k:r[k] for k in ('sequence','group','P_AUC','D_AUC','off_AUC','off_minus_D_AUC','off_minus_P_AUC')} for r in replay])
    shared=list(csv.DictReader((OUT/'shared_parameter_differences.csv').open()))
    state_stats={}
    for label,rows in [('head_and_other_BN_buffers',[r for r in shared if r['key'].endswith(('running_mean','running_var'))]),
                       ('other_floating_state',[r for r in shared if not r['key'].endswith(('running_mean','running_var'))])]:
        # Recover squared reference norm from saved absolute/relative norms, omitting exact-zero differences.
        # This is an upper-bound estimate of relative movement if unchanged tensors exist.
        d2=sum(float(r['absolute_l2'])**2 for r in rows)
        p2=sum((float(r['absolute_l2'])/float(r['relative_l2']))**2 for r in rows if float(r['relative_l2'])>0)
        state_stats[label]={'l2_difference':math.sqrt(d2),'relative_l2_upper_bound':math.sqrt(d2/p2),
                            'tensor_count':len(rows),'changed_tensor_count':sum(float(r['absolute_l2'])>0 for r in rows)}
    out={'probe_state_crop_points':len(parity),'interventions':stats,'message_statistics':message_stats,
         'parity':{'archive_box_max_abs_error_px':max(float(r['native_archive_max_abs_error']) for r in parity),
                   'repeat_max_abs_error_px':max(float(r['repeat_max_abs_error']) for r in parity),
                   'message_reconstruction_max_abs_error':max(float(r['reconstruction_max_abs_error']) for r in parity)},
         'floating_state_change':state_stats,'bn_followup':bn}
    write(OUT/'attribution_summary.json',out)
    params=json.loads((OUT/'parameters.json').read_text());lam=params['coefficients'][-1]['effective_lambda']
    temporal=json.loads((OUT/'temporal_summary.json').read_text())
    doc=['# 差分关系 quick：归因分析', '',
         '**结论：存在“当前差分路径改变闭环轨迹”与“训练后共有状态／参数改变闭环轨迹”两类效应；不是一个统一的去噪失败，更没有证据证明梯度冲突。当前不支持全量晋级。**', '',
         '## 比较身份与测量合同', '',
         'P：EG_DUALMSG_V2_P_QUICK_SOT_S42_20261027；D：EG_DIFFATTN_QUICK_SOT_S42_20261027。两者均由公共SOT预训练单阶段468更新，3744个增强microbatch配对，seed42。P/D u0468 SHA分别为 `3b83c3c6ce4ec8ca4c40a8dc303127bfa7163d2636c790cf3d8522005b496a6f` / `710fd0ed7f9de7c6e3ddf439dab752be000cec35c3a52cd493f6d6ae0ab199f5`。', '',
         '主性能仍是固定96条/54666帧：P AUC56.5444，D55.0746，Δ−1.4698pp。低/中/正常组Δ分别+0.6359/−2.3454/−2.6998pp；分组按P的AUC三分位，不是退化标签。', '',
         f'本轮只做学习后推理：全96条已存轨迹分析；按结果回溯选13条、9424帧闭环D-off；{len(parity)}个共同state/crop，每点off/half/uniform三干预；残留损失3条另做头部BN统计替换。FP32、threads0、无模板更新、单推理进程。完整队列与后补时点规则见PROTOCOL.md/cohort.json，首轮输出保留pass1/。不是独立验证集，不重新报告为96/full性能。', '',
         '## 1. 先排除完整死分支解释', '',
         f'12头u468有效λ全部为正，范围{min(lam):.4f}—{max(lam):.4f}；u234范围0.0453—0.0890。u234→u468，Q/K相对移动8.89%/9.09%。此checkpoint实际在扣减，而不是负系数加法。P0已经证实真实AMP梯度与成功更新；本轮参数轨迹进一步支持分支继续学习。不能由此推断学到了有用关系。', '',
         '最后234步训练平均loss P1.021698、D1.021138，IoU P0.768284、D0.768464，几乎一致；没有整体训练崩溃信号。未测多seed或完整训练进度，因此不能排除短训练及优化设置限制。', '',
         '## 2. 损失以闭环尾部事件为主', '',
         f'最差7条ΔAUC之和{temporal["top7_loss_sum_pp"]:.3f}，而全96条净和{temporal["net_sum_pp"]:.3f}；其余89条均值+{temporal["remaining89_mean_delta"]:.4f}pp。1125个新失败帧中877个来自这7条；同时有723个恢复帧。不能只报低组均值上涨。', '',
         '七条损失序列中，D裁剪目标中心在外1174帧，P为374帧；但全96条D在外7267帧、P7640帧，不能宣称D在所有序列统一增加出界。出界和恢复是反馈链条读数，不是差分算子的已证实初因。', '',
         '## 3. 同输入直接干预：结构尚未显示任务必要性', '',
         '`O_R=A_RR V_R+(A_RT−λB_RT)diag(g_T)V_T`，另一方向同理。只改变新增差分动作，self、原cross消息、Early gate都保留。off不是关掉整条跨模态消息；uniform逐行保留cross扣减质量，但把来源分布均匀化。', '',
         '| 同crop干预 | n | CENTER换峰 | 平均即时IoU变化(pp) | 框坐标变化中位数(px) |',
         '|---|---:|---:|---:|---:|']
    for var in ('off','half','uniform'):
        s=stats[var];doc.append(f'| {var} | {s["n"]} | {s["CENTER_peak_flips"]} | {s["frame_weighted_mean_iou_delta_pp"]:+.6f} | {s["median_abs_box_coordinate_change_px"]:.6f} |')
    m=message_stats
    doc += ['',f'B的cross条件熵均值{m["B_conditional_entropy_over_log64"]["mean"]:.4f}（除以log64）；与均匀分布TV均值{m["B_to_uniform_total_variation"]["mean"]:.4f}。不是严格均匀，但较分散。扣减消息/原cross消息L2比例中位数{m["correction_to_base_message_l2"]["median"]:.4f}、P90={m["correction_to_base_message_l2"]["p90"]:.4f}；不支持仅因系数小就说没有实际作用。', '',
         f'初始模板框空间前景质量：A={m["A_fg_spatial_mass"]["mean"]:.4f}、B={m["B_fg_spatial_mass"]["mean"]:.4f}、均匀参照={m["uniform_fg_spatial_mass"]["mean"]:.4f}。B有弱背景空间偏向，但模板token已经被上下文混合，空间标签不是有害语义真值，也不能据此宣称“准确去背景”。', '',
         f'均匀化在所有{len(parity)}点均未换峰，框坐标最大差{stats["uniform"]["max_abs_box_coordinate_change_px"]:.4f}px。因此**当前checkpoint的任务输出对B的细粒度来源分配不敏感**；尚不支持“收益来自选择性关系消噪”。此干预保留了每行扣减总量，不能证明该总量无效，也不是固定均匀关系匹配重训。', '',
         '`whitecarturn683`，index0=170、P-state：P/D/D-off IoU=0.8797/0.0296/0.8737，直接关闭或减半能切回正确峰；但另一条中性序列index0=789关闭差分会把IoU0.1283变为0，说明同路径也可能有益。平均数由少数换峰主导，不是普遍单调的尺度结论。', '',
         '## 4. 闭环D-off：分开解释，不用一类原因覆盖所有序列', '',
         '| 序列 | P AUC | D AUC | D-off AUC | off相对P |', '|---|---:|---:|---:|---:|']
    for r in sorted(replay,key=lambda r:r['delta_AUC']):
        doc.append(f'| {r["sequence"]} | {r["P_AUC"]:.3f} | {r["D_AUC"]:.3f} | {r["off_AUC"]:.3f} | {r["off_minus_P_AUC"]:+.3f} |')
    doc += ['', '4条大损失（blktribikecome、boy`sheadingreycol、girldownstairfromlight、leftuphand）关闭差分后接近P。支持当前动作对这些序列的闭环损害，局部小变化可跨阈值后反馈放大；不能把AUC恢复比例当可相加的因果贡献。', '',
            'blkboydown/whitegirlinlight关闭仍不恢复，说明已训练D的共有状态与反馈有剩余问题；whitecarturn683关闭反而更差，说明差分既有局部误伤，也可能补偿其他时段。最大增益leftboy2jointhe4关闭后仍在，不能把该序列上涨直接算作差分动作的正贡献；ballshootatthebasket3times关闭后增益消失，说明也不能把分支一概判为无用。', '',
            '## 5. BN统计不是统一首因', '',
            'P/D共有浮点state整体相对L2差1.3819%包含BN buffers，不能称为纯参数移动。排除BN running统计后，其余浮点state相对差上界约0.2437%；BN统计约1.3848%。差异大小不等于因果贡献。', '',
            '| 残留序列 | D-off | D-off仅换P头BN统计 | P |', '|---|---:|---:|---:|']
    for r in bn:doc.append(f'| {r["sequence"]} | {r["D_off_AUC"]:.3f} | {r["D_off_P_BN_AUC"]:.3f} | {r["P_AUC"]:.3f} |')
    doc += ['', 'blkboydown与whitegirlinlight仍未恢复；whitecarturn683仅部分恢复。**排除“仅替换头BN统计足以解释全部残留损失”**，不排除BN与其他表示共同作用。未交换具体权重子组，不能断言是backbone或CENTER参数首因，更不能称梯度冲突。', '',
            '## 下一步只保留一个判别变量', '',
            '暂不支持本版本全量晋级，也不直接增加可靠度/因果/新门控。若继续该线路，最有判别力的一步是：**只把可学习B改成固定均匀B**，保留λ、gain16、Early gate、层位和所有训练合同，从同一公共预训练重新匹配短训，并复用同协议P。检验当前额外关系学习究竟带来何种增量，还是作用主要由扣减总量及共有参数适应产生。已有checkpoint uniform化不能代替这一步。', '',
            '预期与反证：固定B若复制相同尾部模式，优先定位总量/训练适应/反馈问题；若明显恢复且学习型B独有损害，支持关系学习是当前额外风险；若学习型B在后续匹配验证表现更好，则需撤回“细粒度关系缺少任务价值”的更强解释。该建议不是已授权的新训练，本轮未执行。', '',
            '现阶段可写的主张只是：当前局部差分适配改变跨模态消息，学习确实发生，部分序列存在直接路径与闭环效应；**尚未证明识别有害消息、减少正常误伤、与Early gate互补或跨seed稳定收益**。这不是官方完整Differential Transformer复现，不能把此负结果扩展为差分注意力普遍无效。', '',
            '## 证据与校验', '',
            f'原生预测回放最大框坐标误差{out["parity"]["archive_box_max_abs_error_px"]:.8f}px；重复预测误差0；真实消息重构误差0；移除诊断挂钩前后误差0。模型/训练配置未修改。首次工具错误、修复和原始traceback单独保留，不计为方法失败。', '',
            '原始读数：temporal96.csv、iou_curves96.npz、parameters.json、training_trajectory.json、shared_parameter_differences.csv、fixed_crop_probes.json、message_by_head.csv、parity.csv、closed_loop_comparison.csv、bn_followup_results.json。命令/环境/耗时见pass1/completed.json、probe_completed.json、completed.json、bn_followup_completed.json。数据与代码hash见identity.json；诊断源快照在source/。', '',
            '单seed、短预算、回溯挑选13条；固定state/crop干预与闭环关路径都不替代匹配重训。未重新测FPS，本轮诊断吞吐不当成方法性能。']
    (OUT/'REPORT.md').write_text('\n'.join(doc)+'\n')
    # Four diagnostic timelines, not publication/SOTA figures.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    z=np.load(str(OUT/'iou_curves96.npz'))
    names=['blktribikecome','blkboydown','whitecarturn683','leftboy2jointhe4']
    fig,axes=plt.subplots(4,1,figsize=(10,9),constrained_layout=True)
    for ax,name in zip(axes,names):
        gp=ROOT/'data/lasher/testingset'/name/'init.txt'
        off=measure(OUT/'D_off_closed_loop'/(name+'.txt'),gp)['iou']
        for label,values,color in [('P: Early gate',z[name+'__P'],'#333333'),('D: differential',z[name+'__D'],'#d44b3f'),('D: correction off',off,'#26826c')]:
            val=values.copy();val[val<0]=np.nan;ax.plot(val,label=label,color=color,lw=1,alpha=.85)
        ax.set(title=name,ylabel='IoU',ylim=(-.03,1.03));ax.grid(alpha=.2)
    axes[0].legend(ncol=3,fontsize=9);axes[-1].set_xlabel('Frame index (zero based)')
    fig.savefig(str(OUT/'diagnostic_timelines.png'),dpi=160);plt.close(fig)
    print(json.dumps(out,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
