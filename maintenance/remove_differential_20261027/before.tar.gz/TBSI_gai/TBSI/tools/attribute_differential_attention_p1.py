#!/usr/bin/env python3
"""Retrospective learned-checkpoint attribution. No training/admission machinery."""
import argparse
import contextlib
import csv
import hashlib
import io
import json
import math
import os
import platform
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ['TBSI_INFER_FP16'] = '0'
import cv2
import numpy as np
import torch
from tools.analyze_differential_attention_p1 import measure, digest
torch.set_num_threads(1)
cv2.setNumThreads(0)

BASE = Path('/autodl-fs/data/early_gate_closed_loop')
PRUN = BASE / 'dual_message_p1_v2_20261027/runs/P'
DRUN = BASE / 'differential_attention_p1_20261027/runs/D'
DOC = ROOT / 'experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027'
OUT = DOC / 'attribution'
PCFG = ROOT / 'experiments/tbsi_track/EG_DUALMSG_V2_P_QUICK_SOT_S42_20261027.yaml'
DCFG = ROOT / 'experiments/tbsi_track/EG_DIFFATTN_QUICK_SOT_S42_20261027.yaml'


def write(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def table(path, rows):
    with Path(path).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def iou(box, gt):
    box, gt = np.asarray(box, float), np.asarray(gt, float)
    if not np.isfinite(gt).all() or (gt[2:] <= 0).any():
        return None
    area = np.maximum(0, np.minimum(box[:2]+box[2:], gt[:2]+gt[2:]) - np.maximum(box[:2],gt[:2])).prod()
    return float(area / max(1e-12, box[2:].prod()+gt[2:].prod()-area))


def geom(state, gt, factor=4):
    x,y,w,h = map(float,state)
    side = math.ceil(math.sqrt(w*h)*factor)
    x0,y0 = round(x+.5*w-.5*side), round(y+.5*h-.5*side)
    gx,gy,gw,gh = gt
    if gw <= 0 or gh <= 0 or not np.isfinite(gt).all():
        return {'crop_side': side, 'gt_visible_fraction': None, 'gt_center_inside': None}
    inter = max(0, min(x0+side,gx+gw)-max(x0,gx))*max(0,min(y0+side,gy+gh)-max(y0,gy))
    return {'crop_side': side, 'gt_visible_fraction':float(inter/(gw*gh)),
            'gt_center_inside':bool(x0<=gx+.5*gw<=x0+side and y0<=gy+.5*gh<=y0+side)}


def first_run(mask, n=5):
    for k in range(1, len(mask)-n+1):
        if mask[k:k+n].all():
            return k
    return None


def offline():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = list(csv.DictReader((DOC/'analysis_u0468_screen96/per_sequence.csv').open()))
    for r in rows:
        r['delta_AUC'] = float(r['delta_AUC'])
    cohort = [(r,'loss_gt5') for r in rows if r['delta_AUC'] < -5]
    cohort += [(r,'top3_gain') for r in sorted(rows,key=lambda r:r['delta_AUC'],reverse=True)[:3]]
    for group in ('low_auc','middle_auc','normal_auc'):
        r = min([r for r in rows if r['group']==group],key=lambda r:(abs(r['delta_AUC']),r['sequence']))
        cohort.append((r,'neutral_'+group))
    selected, temporal, curves = {}, [], {}
    for r in rows:
        name=r['sequence']; gp=ROOT/'data/lasher/testingset'/name/'init.txt'
        p=measure(PRUN/'eval96'/(name+'.txt'),gp)['iou']
        d=measure(DRUN/'eval96'/(name+'.txt'),gp)['iou']
        pb=np.loadtxt(str(PRUN/'eval96'/(name+'.txt')),ndmin=2)
        db=np.loadtxt(str(DRUN/'eval96'/(name+'.txt')),ndmin=2)
        gt=np.loadtxt(str(gp),delimiter=',',ndmin=2)
        bad=(p>=.5)&(d<.1); good=(d>=.5)&(p<.1)
        bad_start,good_start=first_run(bad),first_run(good)
        dv=[geom(db[k-1],gt[k]) for k in range(1,len(gt))]
        pv=[geom(pb[k-1],gt[k]) for k in range(1,len(gt))]
        temporal.append({'sequence':name,'group':r['group'],'delta_AUC':r['delta_AUC'],'frames':len(gt),
                         'new_failure_frames':int(bad.sum()),'recovery_frames':int(good.sum()),
                         'first_5frame_failure_index0':bad_start,'first_5frame_recovery_index0':good_start,
                         'D_gt_center_outside_crop_frames':sum(g['gt_center_inside'] is False for g in dv),
                         'P_gt_center_outside_crop_frames':sum(g['gt_center_inside'] is False for g in pv),
                         'D_valid_gt_crop_frames':sum(g['gt_center_inside'] is not None for g in dv),
                         'D_failure_start_gt_visible':None if bad_start is None else geom(db[bad_start-1],gt[bad_start])['gt_visible_fraction']})
        curves[name]={'P':p,'D':d}
        chosen=[reason for rr,reason in cohort if rr['sequence']==name]
        if chosen:
            frames={max(1,min(len(gt)-1,int(q*(len(gt)-1)))) for q in (.05,.25,.5,.75,.95)}
            for event in (bad_start,good_start):
                if event is not None:
                    frames.update(k for k in (event-10,event-2,event,event+2,event+10) if 1<=k<len(gt))
            selected[name]={'selection':chosen,'group':r['group'],'delta_AUC':r['delta_AUC'],
                            'frames_index0':sorted(frames),'total_frames':len(gt)}
    table(OUT/'temporal96.csv',temporal)
    np.savez_compressed(str(OUT/'iou_curves96.npz'),**{n+'__'+a:v for n,arms in curves.items() for a,v in arms.items()})
    write(OUT/'cohort.json',selected)
    total=sum(r['delta_AUC'] for r in rows)
    losses=sorted(rows,key=lambda r:r['delta_AUC'])[:7]
    write(OUT/'temporal_summary.json',{'n':len(rows),'selected_n':len(selected),
          'top7_loss_sum_pp':sum(r['delta_AUC'] for r in losses),'net_sum_pp':total,
          'remaining89_mean_delta':sum(r['delta_AUC'] for r in rows if r not in losses)/89,
          'new_failure_frames':sum(r['new_failure_frames'] for r in temporal),
          'recovery_frames':sum(r['recovery_frames'] for r in temporal),
          'new_failure_top7':sum(r['new_failure_frames'] for r in temporal if r['sequence'] in {t['sequence'] for t in losses}),
          'D_crop_center_outside':sum(r['D_gt_center_outside_crop_frames'] for r in temporal),
          'P_crop_center_outside':sum(r['P_gt_center_outside_crop_frames'] for r in temporal)})
    # CPU-only checkpoint inspection, sequential loads to bound memory.
    learned={}
    for step in (234,468):
        obj=torch.load(str(DRUN/('checkpoint_u%04d.pth.tar'%step)),map_location='cpu')
        net=obj['net']
        subset={k:v.clone() for k,v in net.items() if 'cross_differential_attention' in k}
        learned[step]=subset
        del obj,net
    coeff=[]
    for step,net in learned.items():
        for key,val in net.items():
            if key.endswith('coefficient'):
                coeff.append({'update':step,'key':key,'raw':val.tolist(),'effective_lambda':(16*val).tolist()})
    # Initial candidate-only params may be in init state metadata, so compare u234->468 unambiguously.
    moves={k:float((learned[468][k]-v).norm()/v.norm().clamp_min(1e-12)) for k,v in learned[234].items()}
    p=torch.load(str(PRUN/'checkpoint_u0468.pth.tar'),map_location='cpu')['net']
    d=torch.load(str(DRUN/'checkpoint_u0468.pth.tar'),map_location='cpu')['net']
    common=[]
    for key in p:
        if key in d and p[key].is_floating_point():
            common.append({'key':key,'absolute_l2':float((p[key]-d[key]).norm()),
                           'relative_l2':float((p[key]-d[key]).norm()/p[key].norm().clamp_min(1e-12))})
    table(OUT/'shared_parameter_differences.csv',common)
    write(OUT/'parameters.json',{'coefficients':coeff,'relative_movement_u234_to_u468':moves,
          'common_parameter_global_relative_l2':math.sqrt(sum((p[k]-d[k]).square().sum().item() for k in p if k in d and p[k].is_floating_point()) /
                                                        sum(p[k].square().sum().item() for k in p if k in d and p[k].is_floating_point()))})
    del p,d
    pu=[json.loads(s) for s in (PRUN/'updates.jsonl').read_text().splitlines()]
    du=[json.loads(s) for s in (DRUN/'updates.jsonl').read_text().splitlines()]
    training=[]
    for start,end in ((0,50),(50,234),(234,468)):
        training.append({'updates':[start+1,end],**{arm+'_'+key:float(np.mean([r[key] for r in data[start:end]]))
                         for arm,data in [('P',pu),('D',du)] for key in ('loss','iou','gradient_norm')}})
    write(OUT/'training_trajectory.json',training)
    print(json.dumps({'cohort':selected,'coefficients':coeff,'training':training},ensure_ascii=False),flush=True)


def load_tracker(config,checkpoint):
    from lib.test.evaluation.tracker import Tracker
    os.environ['TBSI_CHECKPOINT_OVERRIDE']=str(checkpoint)
    wrapper=Tracker('tbsi_track',config.stem,'lasher_test')
    with contextlib.redirect_stdout(io.StringIO()):
        params=wrapper.get_parameters(); params.debug=0
        tracker=wrapper.create_tracker(params)
    return tracker,wrapper


def frame(seq,index):
    parts=[]
    for stream in seq.frames:
        im=cv2.imread(stream[index])
        if im is None: raise ValueError(stream[index])
        parts.append(cv2.cvtColor(im,cv2.COLOR_BGR2RGB))
    return np.concatenate(parts,2)


def foreground(gt):
    x,y,w,h=map(float,gt); side=math.ceil(math.sqrt(w*h)*2)
    x0,y0=round(x+w/2-side/2),round(y+h/2-side/2)
    gx,gy,gw,gh=(x-x0)*128/side,(y-y0)*128/side,w*128/side,h*128/side
    yy,xx=np.meshgrid(np.arange(8),np.arange(8),indexing='ij')
    wx=np.maximum(0,np.minimum(xx*16+16,gx+gw)-np.maximum(xx*16,gx))
    wy=np.maximum(0,np.minimum(yy*16+16,gy+gh)-np.maximum(yy*16,gy))
    return torch.tensor((wx*wy/256).ravel(),dtype=torch.float32,device='cuda')


class Capture:
    def __init__(self,tracker):
        self.data={}; self.handles=[]
        self.network=tracker.network
        self.original_network_forward=tracker.network.forward
        def network_forward(*args,**kwargs):
            out=self.original_network_forward(*args,**kwargs)
            self.data['out']={k:v.detach() for k,v in out.items() if torch.is_tensor(v)}
            return out
        # The native tracker calls network.forward explicitly, bypassing Module hooks.
        self.network.forward=network_forward
        self.fusion=next(layer.v2_template_fusion for layer in tracker.network.backbone.tbsi_layers
                         if layer.v2_template_fusion.cross_differential_attention_enabled)
        for name,mod in [('norm',self.fusion.norm),('qkv',self.fusion.qkv),('gate',self.fusion.early_gate),
                         ('correction',self.fusion.cross_differential_attention)]:
            self.handles.append(mod.register_forward_hook(self.hook(name)))
        self.handles.append(self.fusion.proj.register_forward_pre_hook(lambda m,a:self.data.update({'preproj':a[0].detach()})))
    def hook(self,name):
        def save(module,args,out):
            self.data[name]=({k:v.detach() for k,v in out.items() if torch.is_tensor(v)} if isinstance(out,dict) else out.detach())
        return save
    def clear(self): self.data={}
    def close(self):
        for h in self.handles: h.remove()
        self.network.forward=self.original_network_forward

    def stats(self,fg):
        f=self.fusion; x=self.data['norm']; n=x.shape[1]//2; b,l,c=x.shape
        qkv=self.data['qkv'].reshape(b,l,3,f.num_heads,f.head_dim).permute(2,0,3,1,4)
        q,k,v=qkv.unbind(0); a=((q@k.transpose(-2,-1))*f.scale).softmax(-1)
        diff=f.cross_differential_attention; theta=diff.coefficient*diff.coefficient_gain
        qd=diff.query(x).view(b,l,diff.num_heads,diff.rank).permute(0,2,1,3)
        kd=diff.key(x).view(b,l,diff.num_heads,diff.rank).permute(0,2,1,3)
        full_b=((qd@kd.transpose(-2,-1))*diff.scale).softmax(-1)
        corr=full_b*theta[None,:,None,None]
        gate=torch.exp(torch.tanh(f.early_gate_scale)*torch.tanh(self.data['gate'])).clamp(.25,4)
        # Verify reconstruction of the actual pre-projection message, including sign and source gate axis.
        msg_r=a[:,:,:n,:n]@v[:,:,:n]+(a[:,:,:n,n:]-corr[:,:,:n,n:])@(v[:,:,n:]*gate[:,None,:,1:2])
        msg_t=a[:,:,n:,n:]@v[:,:,n:]+(a[:,:,n:,:n]-corr[:,:,n:,:n])@(v[:,:,:n]*gate[:,None,:,0:1])
        recon=torch.cat((msg_r,msg_t),2).transpose(1,2).reshape(b,l,c)
        err=float((recon-self.data['preproj']).abs().max())
        rows=[]
        for direction,qs,ks,gate_i in [('TIR_to_RGB',slice(0,n),slice(n,l),1),('RGB_to_TIR',slice(n,l),slice(0,n),0)]:
            aa=a[:,:,qs,ks]; bb=full_b[:,:,qs,ks]; cc=corr[:,:,qs,ks]
            vv=v[:,:,ks]*gate[:,None,:,gate_i:gate_i+1]
            norm_b=bb/bb.sum(-1,keepdim=True).clamp_min(1e-12)
            for h in range(f.num_heads):
                base=aa[0,h]@vv[0,h]; delta=cc[0,h]@vv[0,h]
                bn=norm_b[0,h]; an=aa[0,h]/aa[0,h].sum(-1,keepdim=True).clamp_min(1e-12)
                fg_b=float((bn*fg[None,:]).sum(-1).mean()); fg_a=float((an*fg[None,:]).sum(-1).mean())
                rows.append({'direction':direction,'head':h,'lambda':float(theta[h]),
                    'A_cross_mass':float(aa[0,h].sum(-1).mean()),'B_cross_mass':float(bb[0,h].sum(-1).mean()),
                    'correction_to_base_message_l2':float(delta.norm()/base.norm().clamp_min(1e-12)),
                    'message_cosine':float(torch.nn.functional.cosine_similarity(base.flatten(),delta.flatten(),dim=0)),
                    'negative_effective_weight_fraction':float(((aa-cc)[0,h]<0).float().mean()),
                    'B_conditional_entropy_over_log64':float((-(bn*bn.clamp_min(1e-12).log()).sum(-1)/math.log(n)).mean()),
                    'B_to_uniform_total_variation':float((.5*(bn-1/n).abs().sum(-1)).mean()),
                    'A_fg_spatial_mass':fg_a,'B_fg_spatial_mass':fg_b,'uniform_fg_spatial_mass':float(fg.mean()),
                    'B_vs_A_conditional_l1':float((bn-an).abs().sum(-1).mean()),'message_reconstruction_max_abs':err})
        return rows


def infer(tracker,image,state,index,capture=None):
    tracker.state=list(map(float,state)); tracker.frame_id=index-1
    tracker.prev_search=None;tracker.prev_temporal_tokens=None
    if capture: capture.clear()
    crop_hash=[]; orig=tracker.preprocessor.process
    def process(*a,**kw):
        crop_hash.append(hashlib.sha256(np.ascontiguousarray(a[0]).tobytes()).hexdigest())
        return orig(*a,**kw)
    tracker.preprocessor.process=process
    try:
        with torch.inference_mode(): pred=tracker.track(image)['target_bbox']
    finally: tracker.preprocessor.process=orig
    return np.asarray(pred,float),crop_hash[0]


def probes():
    from tools.run_dual_message_p1 import setup,environment
    from lib.test.evaluation import get_dataset
    setup(42)
    chosen=json.loads((OUT/'cohort.json').read_text())
    dataset={s.name:s for s in get_dataset('lasher_test') if s.name in chosen}
    started=time.time()
    pt,_=load_tracker(PCFG,PRUN/'checkpoint_u0468.pth.tar')
    dt,_=load_tracker(DCFG,DRUN/'checkpoint_u0468.pth.tar')
    cap=Capture(dt); f=cap.fusion; mod=f.cross_differential_attention
    original_forward=mod.forward
    records=[]; messages=[]; parity=[]
    for name,selection in chosen.items():
        seq=dataset[name]; gt=seq.ground_truth_rect
        initial=frame(seq,0); info=seq.init_info()
        pt.initialize(initial,info);dt.initialize(initial,info);fg=foreground(gt[0])
        pb=np.loadtxt(str(PRUN/'eval96'/(name+'.txt')),ndmin=2)
        db=np.loadtxt(str(DRUN/'eval96'/(name+'.txt')),ndmin=2)
        for idx in selection['frames_index0']:
            image=frame(seq,idx)
            for anchor,states in [('P',pb),('D',db)]:
                state=states[idx-1]; common={'sequence':name,'group':selection['group'],'index0':idx,'anchor':anchor,
                      'state':state.tolist(),**geom(state,gt[idx])}
                p,ph=infer(pt,image,state,idx)
                f.cross_differential_attention_enabled=True
                mod.forward=original_forward
                native,dh=infer(dt,image,state,idx,cap)
                with torch.inference_mode(): stats=cap.stats(fg)
                messages.extend([{**{k:common[k] for k in ('sequence','group','index0','anchor')},**s} for s in stats])
                score=cap.data['out']['score_map']; response=score*dt.output_window
                base_score=score.clone();native_peak=int(response.flatten().argmax())
                repeat,rh=infer(dt,image,state,idx,cap)
                if ph!=dh or dh!=rh or not np.array_equal(native,repeat):
                    raise ValueError('Fixed-input or repeat parity failed')
                for variant in ('off','half','uniform'):
                    f.cross_differential_attention_enabled=variant!='off'
                    if variant=='half':
                        mod.forward=lambda x:original_forward(x)*.5
                    elif variant=='uniform':
                        def uniform(x):
                            correction=original_forward(x);n=correction.shape[-1]//2
                            correction=correction.clone()
                            correction[:,:,:n,n:]=correction[:,:,:n,n:].mean(-1,keepdim=True)
                            correction[:,:,n:,:n]=correction[:,:,n:,:n].mean(-1,keepdim=True)
                            return correction
                        mod.forward=uniform
                    else: mod.forward=original_forward
                    pred,vh=infer(dt,image,state,idx,cap)
                    if vh!=dh: raise ValueError('Crop mismatch')
                    score2=cap.data['out']['score_map']; peak=int((score2*dt.output_window).flatten().argmax())
                    records.append({**common,'variant':variant,'crop_sha256':dh,'P_box':p.tolist(),'D_box':native.tolist(),
                        'intervention_box':pred.tolist(),'P_iou':iou(p,gt[idx]),'D_iou':iou(native,gt[idx]),
                        'intervention_iou':iou(pred,gt[idx]),'D_CENTER_peak':native_peak,'intervention_CENTER_peak':peak,
                        'CENTER_max_abs_change':float((score2-base_score).abs().max()),
                        'box_max_abs_change':float(np.max(np.abs(pred-native)))})
                f.cross_differential_attention_enabled=True;mod.forward=original_forward
                archive=pb[idx] if anchor=='P' else db[idx]
                current=p if anchor=='P' else native
                parity.append({'sequence':name,'index0':idx,'anchor':anchor,'native_archive_max_abs_error':float(np.max(np.abs(current-archive))),
                               'repeat_max_abs_error':float(np.max(np.abs(native-repeat))),
                               'reconstruction_max_abs_error':max(s['message_reconstruction_max_abs'] for s in stats)})
        write(OUT/'fixed_crop_probes.json',records);table(OUT/'message_by_head.csv',messages);table(OUT/'parity.csv',parity)
        print(json.dumps({'probe_sequence':name,'samples':len(records),'seconds':time.time()-started}),flush=True)
    # Hook removal must preserve predictions; test one exact native case once more.
    f.cross_differential_attention_enabled=True;mod.forward=original_forward
    hooked,_=infer(dt,image,state,idx,cap);cap.close();bare,_=infer(dt,image,state,idx)
    if not np.array_equal(hooked,bare): raise ValueError('Hook no-op parity failed')
    write(OUT/'probe_completed.json',{'environment':environment(),'command':sys.argv,'seconds':time.time()-started,
          'state_crop_samples':len(parity),'variants':3,'rows':len(records),'hook_noop_max_abs_error':float(np.max(np.abs(hooked-bare))),
          'max_archive_error':max(r['native_archive_max_abs_error'] for r in parity),'gpu_wall_hours':(time.time()-started)/3600})
    # Release P before sequential diagnostic closed-loop replay.
    del pt
    replay=OUT/'D_off_closed_loop';replay.mkdir(exist_ok=True)
    f.cross_differential_attention_enabled=False
    replay_rows=[]
    for name,selection in chosen.items():
        seq=dataset[name];gp=ROOT/'data/lasher/testingset'/name/'init.txt';target=replay/(name+'.txt')
        if not target.exists():
            dt.initialize(frame(seq,0),seq.init_info());boxes=[seq.init_info()['init_bbox']]
            for idx in range(1,len(seq.ground_truth_rect)):
                with torch.inference_mode(): pred=dt.track(frame(seq,idx))['target_bbox']
                boxes.append(pred)
            np.savetxt(str(target),np.asarray(boxes),fmt='%.9f',delimiter='\t')
        scores={a:measure(folder/(name+'.txt'),gp) for a,folder in [('P',PRUN/'eval96'),('D',DRUN/'eval96'),('off',replay)]}
        replay_rows.append({'sequence':name,**selection,**{a+'_'+key:v for a,m in scores.items() for key,v in m.items() if key!='iou'}})
        write(OUT/'closed_loop_results.json',replay_rows)
        print(json.dumps({'closed_loop_D_off':name,'P_AUC':scores['P']['AUC'],'D_AUC':scores['D']['AUC'],'off_AUC':scores['off']['AUC']}),flush=True)
    write(OUT/'completed.json',{'environment':environment(),'command':sys.argv,'seconds':time.time()-started,
          'gpu_wall_hours':(time.time()-started)/3600,'closed_loop_n':len(replay_rows),
          'closed_loop_frames':sum(r['total_frames'] for r in replay_rows),'no_training':True})


def bn_followup():
    from tools.run_dual_message_p1 import setup,environment
    from lib.test.evaluation import get_dataset
    setup(42);started=time.time()
    previous=json.loads((OUT/'closed_loop_results.json').read_text())
    # Adaptive diagnostic, not a new validation cohort or a method-performance ranking.
    selected=[r for r in previous if 'loss_gt5' in r['selection'] and r['off_AUC']-r['P_AUC'] < -5]
    write(OUT/'bn_followup_selection.json',{'rule':'original seven losses; residual D-off minus P AUC < -5pp',
          'selected':[r['sequence'] for r in selected],'comparison':'D-off with its own BN vs D-off with P head running stats'})
    dt,_=load_tracker(DCFG,DRUN/'checkpoint_u0468.pth.tar')
    for layer in dt.network.backbone.tbsi_layers:
        layer.v2_template_fusion.cross_differential_attention_enabled=False
    p=torch.load(str(PRUN/'checkpoint_u0468.pth.tar'),map_location='cpu')['net']
    original={name:value.detach().clone() for name,value in dt.network.named_buffers()
              if name.startswith('box_head.') and name.endswith(('running_mean','running_var','num_batches_tracked'))}
    swapped=[]
    with torch.no_grad():
        for name,value in dt.network.named_buffers():
            if name in original:
                value.copy_(p[name]);swapped.append(name)
    del p
    dataset={s.name:s for s in get_dataset('lasher_test') if s.name in {r['sequence'] for r in selected}}
    out=OUT/'D_off_P_head_BN';out.mkdir(exist_ok=True);results=[]
    for r in selected:
        name=r['sequence'];seq=dataset[name]
        dt.initialize(frame(seq,0),seq.init_info());boxes=[seq.init_info()['init_bbox']]
        for idx in range(1,len(seq.ground_truth_rect)):
            with torch.inference_mode(): pred=dt.track(frame(seq,idx))['target_bbox']
            boxes.append(pred)
        target=out/(name+'.txt');np.savetxt(str(target),np.asarray(boxes),fmt='%.9f',delimiter='\t')
        metrics=measure(target,ROOT/'data/lasher/testingset'/name/'init.txt')
        row={'sequence':name,'P_AUC':r['P_AUC'],'D_AUC':r['D_AUC'],'D_off_AUC':r['off_AUC'],
             **{'D_off_P_BN_'+key:v for key,v in metrics.items() if key!='iou'}}
        results.append(row);write(OUT/'bn_followup_results.json',results);print(json.dumps(row),flush=True)
    with torch.no_grad():
        for name,value in dt.network.named_buffers():
            if name in original: value.copy_(original[name])
    write(OUT/'bn_followup_completed.json',{'environment':environment(),'command':sys.argv,'seconds':time.time()-started,
          'gpu_wall_hours':(time.time()-started)/3600,'swapped_head_buffers':swapped,'restored':True,'n':len(results),
          'scope':'diagnostic checkpoint hybrid only; not deployable method comparison; no retraining'})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['offline','probes','bn']);args=parser.parse_args()
    if args.stage=='offline': offline()
    elif args.stage=='probes': probes()
    else: bn_followup()


if __name__=='__main__': main()
