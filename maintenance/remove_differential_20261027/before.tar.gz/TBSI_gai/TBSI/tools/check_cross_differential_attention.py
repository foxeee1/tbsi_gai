#!/usr/bin/env python3
"""Focused parity and gradient contract for cross differential attention."""
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    from lib.models.layers.tbsi_layer import V2TemplateFusion

    torch.manual_seed(20261027)
    dim, heads, batch, tokens = 24, 3, 2, 5
    parent = V2TemplateFusion(dim, heads, attn_drop=0.25,
                              early_conditioned_cross_gate=True)
    candidate = V2TemplateFusion(dim, heads, attn_drop=0.25,
                                 early_conditioned_cross_gate=True,
                                 cross_differential_attention=True,
                                 cross_differential_rank=4)
    missing, unexpected = candidate.load_state_dict(parent.state_dict(), strict=False)
    expected_missing = {'cross_differential_attention.query.weight',
                        'cross_differential_attention.key.weight',
                        'cross_differential_attention.coefficient'}
    if set(missing) != expected_missing or unexpected:
        raise RuntimeError('Unexpected disabled-path state contract: %r / %r' %
                           (missing, unexpected))
    if any('cross_differential_attention' in key for key in parent.state_dict()):
        raise RuntimeError('Feature-off construction added state keys')

    rgb = torch.randn(batch, tokens, dim)
    tir = torch.randn(batch, tokens, dim)
    context = tuple(torch.randn(batch, tokens, dim) for _ in range(2)) + tuple(
        torch.randn(batch, 7, dim) for _ in range(2))
    parent.train()
    candidate.train()
    torch.manual_seed(811)
    parent_out = parent(rgb, tir, context)
    torch.manual_seed(811)
    candidate_out = candidate(rgb, tir, context)
    diffs = [float((a - b).abs().max()) for a, b in zip(parent_out, candidate_out)]
    if max(diffs) != 0.0:
        raise RuntimeError('Zero-coefficient output parity failed: %r' % diffs)

    candidate.zero_grad(set_to_none=True)
    loss = sum(part.square().mean() for part in candidate(rgb, tir, context))
    loss.backward()
    operator = candidate.cross_differential_attention
    coeff_grad = float(operator.coefficient.grad.norm())
    if not torch.isfinite(operator.coefficient.grad).all() or coeff_grad == 0:
        raise RuntimeError('Zero-init coefficient did not receive finite nonzero gradient')
    with torch.no_grad():
        operator.coefficient.add_(0.05)
    candidate.zero_grad(set_to_none=True)
    sum(part.square().mean() for part in candidate(rgb, tir, context)).backward()
    q_grad = float(operator.query.weight.grad.norm())
    k_grad = float(operator.key.weight.grad.norm())
    if not (torch.isfinite(operator.query.weight.grad).all() and
            torch.isfinite(operator.key.weight.grad).all() and q_grad > 0 and k_grad > 0):
        raise RuntimeError('Relation projections did not receive finite nonzero gradients')

    print(json.dumps({'status': 'PASS', 'disabled_state_keys': len(parent.state_dict()),
                      'candidate_missing_keys': missing, 'unexpected_keys': unexpected,
                      'zero_coefficient_max_abs_output_delta': max(diffs),
                      'coefficient_grad_norm_at_zero': coeff_grad,
                      'query_grad_norm_after_nonzero_coefficient': q_grad,
                      'key_grad_norm_after_nonzero_coefficient': k_grad,
                      'attention_dropout': 0.25}, sort_keys=True))


if __name__ == '__main__':
    main()
