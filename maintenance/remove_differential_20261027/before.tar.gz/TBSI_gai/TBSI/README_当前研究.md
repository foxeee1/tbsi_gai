- **2026-10-27 最新实测与方向评议**：row-centered差分已按用户授权完成公共SOT fresh单阶段468更新及固定96条/54,666帧评测；与P的共有初态及3744个增强microbatch匹配。总体ΔAUC -1.5689pp，低/中/正常组三分位分别-0.2177/-3.6825/-0.8066pp，40胜/3平/53负；原7条大损失救回2条、仍有5条且新增4条。当前候选不进入full。详见[实测结果](experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027/ROW_CENTERED_RESULTS.md)。用户本轮询问是否放弃；[独立评议](experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027/POST_QUICK_DIRECTION_REVIEW.md)建议暂停独立B扣减这一实现、以原Early gate/P为参照考虑搜索响应引导的关系校准；替代方向仅是建议，未成为新执行合同。下方旧“未执行/固定均匀B下一步/唯一EVDR”描述均保留作历史，不自动恢复。

- **2026-10-27 尾部挽救讨论（历史提案，随后已执行row-centered）**：实际40胜/3平/53负；去掉7大损失与3大增益后86条均值仅+0.0241pp，不能称多数稳定上涨。针对挽救尾部，提出只去除cross差分图行均值的单变量候选，保留关系重分配、去除共同扣减；若采纳，将替代固定均匀B作为下一短训臂，不并行扩展。详见[挽救判断与算子公式](experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027/attribution/RESCUE_ASSESSMENT.md)。此条只描述当时提案状态，完成状态以上条实测为准。

- **2026-10-27 差分候选学习后归因已完成**：358个共同state/crop、13条D-off闭环及3条BN统计诊断。4/7条大损失关差分后接近P，另外3条未恢复或更差；均匀化新增来源关系358点均未换CENTER峰；不支持已学到有用的细粒度去噪。BN统计不是统一充分解释。未训练、未启动full；当前下一步仅是固定均匀B的匹配重训建议，尚未执行。详见[归因报告](experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027/attribution/REPORT.md)。该状态覆盖下方旧候选/计划表述，历史证据保留。

- **2026-10-27 最新用户选型修正（覆盖下方旧执行计划）**：用户已停止 E/D campaign 并拒绝 AFF 接收门控；当前只作2025–2026一手算子筛选，不恢复训练/测试、不实现模型。建议优先研究差分注意力的cross块适配，NLformer token内低秩内容分支仅备选，不同时叠加；均未验证任务收益、未成为执行合同。详见[新算子选型与明确问题映射](experiments/early_gate_closed_loop_20261026/dual_message_plan_20261027/module_scout_2025_2026_20261027/RECOMMENDATION.md)。AFF原建议保留并标记撤回。QSTNet已核验作者代码的差异投票加权，出版信息与前文链接未对齐；CMCLTrack一手算子仍待核验。

- **2026-10-27 最新状态（覆盖下方旧计划状态）**：已按用户要求清理12个废弃/冗余中间权重，释放15,896,193,844 bytes；保留性能/逐序列结果/日志/报告，4941个非权重文件hash一致，保护及保留最终权重校验通过。清理证据：`/root/autodl-tmp/maintenance/cleanup_20261027_abandoned_weights/after.json`。E/D具体算子与当前草稿问题见[OPERATORS_V2.md](experiments/early_gate_closed_loop_20261026/dual_message_implementation_20261027/OPERATORS_V2.md)：逐模板token空间编码，既有attention运输证据，完整head消息拼接后小投影，self/cross独立接收动作。V2尚未实现。旧草稿P首次启动在公共初态导出时磁盘满而失败，0训练step；没有C/E/ED学习后结果，本轮未重启训练。旧草稿实现/构造检查不能冒充V2已通过。
- **2026-10-27 后续执行指令**：用户授权继续E/D V2实验。唯一当前合同为[PROTOCOL_V2.md](experiments/early_gate_closed_loop_20261026/dual_message_implementation_20261027/PROTOCOL_V2.md)，按P0真实数据传导→P/C/E/ED串行quick→学习后归因→有信号时配对full执行。V2算子规格在[OPERATORS_V2.md](experiments/early_gate_closed_loop_20261026/dual_message_implementation_20261027/OPERATORS_V2.md)。P0及四臂结果尚待本轮执行，不将之前失败的零步P算作P1。

- **2026-10-27 早先计划草案（历史）**：用户要求联合证据建模及同/跨模态消息分工，建议见[空间证据E＋分工调制D](experiments/early_gate_closed_loop_20261026/dual_message_plan_20261027/PLAN.md)。限定两项主要设计：E保留空间/单模态私有与联合证据，D由Early gate扩展self/cross独立动作；原Early gate保留作对照和可回退起点，独立OT-T暂不并行推进。A_RR/A_TT是模板—模板，不能冒充直接模板—搜索去背景；不一致不自动是冲突，不确定性与因果先明确读数和边界。E内单项support辅助监督须有同监督/容量控制。该早先草案的“尚未改代码”只表示当时状态；后续旧草稿实现与本轮V2具体规格须区分。

- **原版公式入口**：[原Early gate核心公式与真实信息流](experiments/early_gate_closed_loop_20261026/early_gate_current_formula_20261027/FORMULAS.md)。d_i未被确定为下一版证据；原版三项early证据、逐来源双向gate、softmax后cross-Value缩放与间接任务监督必须和新提案区分。

- **上一轮两机制讨论，保留历史**：[G*＋关系T](experiments/early_gate_closed_loop_20261026/gate_transport_scope_20261027/DIRECTION.md)。本轮用户扩大同/跨调制职责后，优先级由E+D计划替代，未通过实验否定T。目标支持差值一直是候选定义，不是已接受/有效的最终G*；旧候选/排队/唯一协议不自动恢复。

- **上一版架构论证，保留为历史草案**：[关系表征校准与双向部分匹配](experiments/early_gate_closed_loop_20261026/orthogonal_msha_draft_20261027/DESIGN_DRAFT.md)及其[LITERATURE.md](experiments/early_gate_closed_loop_20261026/orthogonal_msha_draft_20261027/LITERATURE.md)。C+T同时扩展的优先级已被本次两机制范围替代，不是其效果被实验否证。公共SOT单阶段训练、独立算子、保护资产、资源及登记规则继续有效。

- **上一轮Value局部原型，保留作诊断参照**：[目标支持对比与跨来源抑制](experiments/early_gate_closed_loop_20261026/target_support_design_20261027/DESIGN.md)。当时只完成源码/旧读数再分析、两个默认关闭的独立算子原型及21项CPU代数合同检查，未接入主模型、未训练、未评测。max及五统计量丢失搜索位置信息可由反例确认，但不是历史性能回落首因的证明。本轮不把该原型与新C/T自动叠加。

- 2026-10-27 正常组保护单变量（历史执行计划）：EVDR receiver运输保留前向，只隔离新增条件通过attention回传的梯度；独立模块/新配置/公共SOT fresh468。协议见 [PROTOCOL.md](experiments/early_gate_closed_loop_20261026/evdr_transport_grad_20261027/PROTOCOL.md)。当时已排队等待full244测试后串行训练→同96测试；当前不自动恢复排队，不能称已恢复−0.2265pp。

- Early gate 本身的EI投稿检查（区别于EVDR）：[REVIEW.md](experiments/early_gate_closed_loop_20261026/early_gate_only_submission_20261027/REVIEW.md)。当前动机清楚，但动态early证据与固定方向偏置尚未区分；建议B/C/E匹配检验，不把历史单点涨幅当因果证明。

# 2026-10-27 投稿证据检查与 full 状态修正

- 用户已授权 EVDR receiver-transport 的独立 full15 训练/全244测试，ID：EG-EVDR-ALIGNED-FULL15-SOT-S42-20261027；从公共SOT权重fresh单阶段开始，worker4单任务、7020成功updates，显式终点checkpoint。以实际 progress/completed 文件为准；下文“full尚未启动/不晋级”保留为此前quick判断，不能覆盖这次授权。
- 六项投稿复核见 [REVIEW.md](experiments/early_gate_closed_loop_20261026/submission_audit_20261027/REVIEW.md)。当前表达能力动机可成立，但尚无匹配parent的确认收益、方向专属性消融、三强基线/跨数据集与配对效率证据；没有声称达到3/5或新颖性已确认。该检查不作为阻止有界探索的旧准入器。
- quick/full方向比较还缺同公共SOT、同runner/数据/软件/15epoch预算的fresh Early gate full对照。历史56.56只作参考；先在同96上隔离训练进度，再比较同full权重在96/full244上的范围效应。当前不据此额外并行启动训练。

# 当前执行状态（2026-10-26，历史阶段记录）

- 有效配对SOT-v3 quick已完成：Early gate AUC56.5444，EVDR-v1 54.3660，96条/54666帧；低组+0.0394pp、正常组−3.5240pp。该名单为≤2000帧开发cohort，不是总体无偏估计。full尚未启动；quick/full方向未校准。
- 本轮收紧：仅检验receiver条件从同位置token改为既有cross attention运输的receiver上下文。依据是已学习checkpoint的时间定位与330个共同crop干预；尚未证明其为退化首因。步长、层位、rank、loss、gate、数据和优化器都不改；不新增前景/可靠度网络。
- 唯一当前协议：[evdr_scope_v2_20261026/PROTOCOL.md](experiments/early_gate_closed_loop_20261026/evdr_scope_v2_20261026/PROTOCOL.md)。独立算子early_conditioned_value_direction_aligned.py、显式RECEIVER_MODE=attention，v1默认行为保留。
- P0轴/身份/范数/真实GT梯度检查已完成，共同初态hash与已完成control相同。本轮EG_EVDR_ALIGNED_P1_SOT_S42_20261026已完成468步及同96配对测试；总体ΔAUC-0.4274pp，低组+0.4510pp，正常组-0.2265pp（均相对Early gate）。状态：EXPLORATORY-MIXED / MECHANISM-UNRESOLVED / NO-FULL-PROMOTION。完整结论见evdr_scope_v2_20261026/RESULTS.md。
- 结果与状态只认evdr_scope_v2_20261026中的原始产物、RESULTS.md及双资产表。下文P0/续训/旧未来计划是历史背景，不能覆盖当前协议。

# 当前研究入口

这是后续工作的默认入口。历史报告保留为证据，不共同充当当前计划。

## 2026-10-27 差分注意力快速配对结果

- 按最新用户请求测试 Early gate + 低秩 cross-relation subtraction。P0 最初只有系数更新；采用有效系数λ=16θ的参数化（仅零初始化时保持身份，学习后参与前向）后，真实 AMP batch 上 Q/K 从第2步起获得非零梯度并更新。详细合同与原因见 `experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027/PROTOCOL.md`。
- P1 与同协议 Early gate P 均从公共 SOT 权重独立单阶段训练468成功更新；初始共有参数 hash 与增强后3744 microbatch输入完全匹配。96序列 FP32配对评测完成，候选相对 P 总体ΔAUC -1.4698pp；低AUC组三分位+0.6359pp但区间跨零，中组-2.3454pp，正常组-2.6998pp。结论为总体负向且正常/中组有损伤，不进入全量训练。
- 完整逐序列表、组别和结论见 `experiments/early_gate_closed_loop_20261026/differential_attention_p1_20261027/RESULTS.md` 与 `analysis_u0468_screen96/`。P与候选checkpoint及完整评测identity保存在 `/autodl-fs/data/early_gate_closed_loop/`。

## 当前范围

- 受保护研究参照：M1 TBSI_E_MHSA_FULL_4090D_seed42。4090D等效复现组具有独立身份，按根规则和资产表分别引用。
- 方法研究直接parent：Early-conditioned MSHA gate full15。用户已确认其历史涨点是本次设计起点，配置、checkpoint、日志、指标均保留。
- 目标：沿《新方案》的可靠跨模态模板Value传播方向，在北京时间2026-10-26—2026-11-01获得可证伪的机制结论；不以截止日期保证显著提升。
- 当前唯一候选：EVDR，Early-conditioned Value Direction Repair。独立原型及合同核验，不是已确认涨点或新颖性结论。
- 闭环审计v2已按最新用户指令启用：先做独立工具的真实监督传导，再做有界配对学习，学习后补机制归因；不要求未训练模块先涨点。当前P0独立工具实测与状态见audit_v2。P1续训误设已取消；当前有效P1见p1_sot_v3，必须从公共SOT权重单阶段联合训练。共同初态、数据清单、输入记录和成功step随实施创建/核验，不再仅因没有旧文件停止工作。旧DCVR-v2、ECLVR、STSER和旧A/B/C不自动恢复。

## 默认只读入口

1. 根AGENTS.md第10/11节和本目录AGENTS.md：持续生效的逻辑闭环、隔离实现与实验边界。
2. experiments/实验资产数据库.md及experiment_asset_registry.csv：权威增量登记。
3. experiments/early_gate_closed_loop_20261026/audit_v2/AUDIT_RULES_V2.md及PLAN.md、RESULTS.md、run_contract.json：当前合同与状态；PROTOCOL.md保留v1几何/对照设计，冲突的准入顺序已被v2替代。
4. 同目录LITERATURE.md：2026一手文献核验及尚未闭合的新颖性问题；PAPER_CHAIN.md：论文证据骨架。
5. experiments/主实验/配置/中的M1与Early gate原YAML；output/主实验/实验/中的对应checkpoint。清理移动路径不更改受保护文件身份或hash。
6. 定向需要历史证据时再读experiments/主实验/报告/中的bottleneck/repeatability报告及过去废弃实验/报告/reports/中的旧Value重构报告。不默认扫描全部旧报告或恢复其未来计划。
7. 源码以lib/models/layers/tbsi_layer.py、early_conditioned_msha_gate.py、early_conditioned_value_direction.py和实际调用链为准。

## 当前证据边界

| 事项 | 可说明范围 |
|---|---|
| M1 AUC56.21 | 固定保护参考；不靠覆盖指标解决历史来源风险 |
| Early gate历史AUC56.56 | 单运行点估计；无新鲜matched gate-off，不能直接归因为门控稳健收益 |
| 旧quick3 | 历史512×3、batch16/累积8只有12个更新边界；quick7不能代表完整性能 |
| 当前parent实现 | 本轮修复tbsi_e分支缺失、source/query广播错轴、死legacy构造和配置/forward兼容；完整Early gate权重key匹配及新增分支零初始化parity已检查，不等于历史full244锚点复现 |
| 新EVDR | 只修改cross-source Value方向，原gate负责幅度；前景仅用于离线分层，不输入v1算子 |
| 真实GT检查 | 两条训练序列、固定容易crop、8次FP32新模块更新；只支持图/梯度合同，不是充分过拟合或效果验证 |
| 软件 | 当前Python3.8.20、PyTorch2.0.0+cu118；不同于M1历史1.9/cu111，不称严格复现 |
| 多次模块失败 | 不能统一归因为MSHA、head、模块容量或训练量；先区分合同和机制 |

## 清理与版本

清理前保存：Git c0f1aff98792d604110a1e006a7d2cef4394734d，分支archive/research-state-20261026。原清理清单及路径迁移见../../maintenance/cleanup_20261026/README.md与folder_cleanup_manifest.md。

本轮不把原有大量Git删除当作本轮改动，也不恢复整棵旧代码树。根规则指定的资产主表、CSV与说明文件已从清理归档副本恢复到experiments/权威路径，归档原文保持。原始产物若已删除，不能因表中仍登记就称可复算。

本轮改动前快照位于当前研究目录snapshot_before/；完成时另存snapshot_after/及本轮diff。新算子必须在layers独立.py文件中，宿主只保留显式开关和张量转接。

## 2026-10-26 用户训练初始化修正（优先）

所有后续快速/全量和新模块统一从公共TBSI SOT预训练开始单阶段端到端训练，fresh optimizer/scheduler；不得从M1、Early gate full15或quick checkpoint续训。完整full从同公共预训练独立启动，与quick保持训练前缀合同。Early gate full15只作问题分析参照。错误p1_run continuation control已停止并保留无效记录，当前有效合同p1_sot_v3/PROTOCOL.md。
